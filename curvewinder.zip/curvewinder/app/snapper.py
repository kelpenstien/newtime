import datetime

from unitymarkets.common.core.constant import Environment, Location
from unitymarkets.common.models import ObjectMoniker, MarketDataSet, DataObject
from unitymarkets.interface.session import Session
from unitymarkets.interface.callback import MarketDataCallback
from unitymarkets.common.core.concurrency import synchronized

from finglib.bind import fpx

import sortedcontainers
import uvicorn

from fastapi import FastAPI
from contextlib import asynccontextmanager

# escape and rewind
class RewindKCurve:
    def __init__(self, fpx, today, keep_curve_history_for_x_minutes, snap_every_x_seconds):
        self.fpx = fpx
        self.today = today

        self.mkt_name = "REWIND_"
        self.mkt = fpx.MktCreate(self.mkt_name)

        self.mkt_levels_max_len = keep_curve_history_for_x_minutes * 60 / snap_every_x_seconds
        self.l_mkt_levels = sortedcontainers.SortedKeyList(key=lambda x: x[0])

    def add_root_kcurve(self, root_kcurve):
        self.fpx.MktSetDealDate(self.mkt_name, self.today)
        fingal_set_data = ['usdh15ff.hst.SetData', 'USD:1m:1m.SetData', 'USD:3m:3m.SetData', 'USD:SOFR.SetData']
        fpx().MktSetDataLoad(self.mkt_name, fingal_set_data)
        self.fpx.MktLoadFromString(self.mkt_name, root_kcurve, None, None, False)

    def add_mkt_levels(self, market_levels, ts):
        # magic number 420! lulz..
        # we snap curves every 5 seconds ~ so we start dropping after 35 minutes
        # which is ... 35 minutes * 60 seconds / 5 seconds - > which
        if len(self.l_mkt_levels) > self.mkt_levels_max_len:
            drop_ts, _ = self.l_mkt_levels.pop(0)
            print(f"Dropping mkt levels recvd @ {drop_ts}")
        print(f"Adding mkt levels recvd @ {ts}")
        self.l_mkt_levels.add((ts, market_levels))

    def retrieve(self, ts):
        at = self.l_mkt_levels.bisect_key_right(ts)
        lat = at - 1
        found_ts, mkt_levels = self.l_mkt_levels[lat]
        if (ts - found_ts).seconds > 15:
            return None
        self.fpx.MktReplaceBuildArg(f"{self.mkt_name}USD.KCurve","MarketLevels", mkt_levels, True)
        return self.fpx.MktSaveToString(self.mkt_name, None, None, None)

    def keep_kcurve_snapshot(self, last_update_time, mkt_name = None):
        # extract Market Levels and store those....
        use_mkt_name = self.mkt_name if mkt_name is None else mkt_name
        mkt_levels = self.fpx.MktBuildArgs(use_mkt_name, "USD.Kcurve", "MarketLevels")
        self.add_mkt_levels(mkt_levels, last_update_time)



class KCurveCallback(MarketDataCallback):
    def __init__(self, fpx, rewind, today, snap_every_x_secs=5):
        self.fpx = fpx
        self.today = today
        self.last_update_time = None
        self.rewind = rewind
        self.initialized = False
        self.snap_every_x_seconds = snap_every_x_secs

    def load_curve(self, mkt_name, kcurve_str):
        self.fpx.MktLoadFromString(mkt_name, kcurve_str, None, None, False)
        self.fpx.MktSetDealDate(mkt_name, self.today)


    @synchronized
    def on_update(self, market_dataset: MarketDataSet):
        if self.initialized is False:
            return

        if len(market_dataset.get_data()) <= 0:
            return None
        data = market_dataset.get_data()[0]
        data_inst = data.get_instance()
        last_update_time = data_inst.get_last_updated()

        if self.last_update_time is None:
            print(f"umd first update received on: {data.get_moniker()} @ {last_update_time}.")
            self.rewind.add_root_kcurve(data_inst.get_data())
            self.rewind.keep_kcurve_snapshot(last_update_time)
            self.last_update_time = last_update_time

        elif (last_update_time - self.last_update_time).seconds < self.snap_every_x_seconds:
            # ignore curves within 5 seconds of each other to preserve our sanity
            return

        else:
            print(f"umd update received on: {data.get_moniker()} @ {last_update_time}.")
            self.load_curve("SF_", data_inst.get_data())
            self.rewind.keep_kcurve_snapshot(last_update_time, mkt_name="SF_")
            self.last_update_time = last_update_time

    def on_close(self, data_object: DataObject):
        pass

    def on_error(self, exception: Exception):
        print("-" * 70)
        print("Failure => Error on subcription....")
        print(exception)
        print("-" * 70)

    def on_initialised(self, initialSet):
        self.initialized = True



class UMDManager:
    def __init__(self, client_id, user_id, app_id, env = Environment.Staging, location = Location.Tokyo):
        self.client_id = client_id
        self.user_id = user_id
        self.app_id = app_id
        self.env = env
        self.loc = location

        self.session = None
        # monikers -> (objmoniker, subscription)
        self.d_subscriptions = dict()

    def connect(self):
        self.session = Session.builder().with_environment(self.env) \
            .with_location(self.loc) \
            .with_client_id(self.client_id) \
            .with_reuters_user(self.user_id, self.app_id) \
            .build()
        return self.session

    def cleanup(self):
        if self.session is None:
            return
        self.session.close()
        self.session = None

    def setup_kcurve_subscription(self, moniker, kcurve_callback):
        mobj = ObjectMoniker.from_moniker(moniker)
        umd_sub_service = self.session.get_subscription_service()
        self.d_subscriptions[moniker] = (umd_sub_service, mobj, kcurve_callback)
        umd_sub_service.subscribe_object_moniker(mobj, kcurve_callback)

    def del_kcurve_subscription(self, moniker):
        (umd_sub_service, mobj, kcurve_callback) = self.d_subscriptions[moniker]
        umd_sub_service.unsubscribe_object_moniker(mobj, kcurve_callback)


@asynccontextmanager
async def lifespan(app: FastAPI):

    keep_curve_history_for_x_minutes = 35
    snap_every_x_seconds = 5

    t = datetime.date.today()

    rewind = RewindKCurve(fpx(), t, keep_curve_history_for_x_minutes, snap_every_x_seconds)
    app.state.rewind = rewind

    #umd = UMDManager("usdkcurveutp", "1009168", "470", Environment.Staging, Location.Tokyo)
    umd = UMDManager("usdkcurveutp", "1009168", "470", Environment.Production, Location.Tokyo)
    umd.connect()
    kcurve_callback = KCurveCallback(fpx(), rewind, t)
    umd.setup_kcurve_subscription('rates.pricing.us.usd.live/fingal.kcurve/USD.KCurve', kcurve_callback)

    yield
    # stuff after yield get executed at shutdown
    umd.del_kcurve_subscription()
    umd.cleanup()


app = FastAPI(lifespan=lifespan)


@app.get("/kcurve")
async def get_kcurve(time: str):
    #timestamp format in yyyy-mm-ddThh:mm:ss (2025-06-04T07:20:14)
    rewind_kcurve = app.state.rewind
    kcurve_str = rewind_kcurve.retrieve(datetime.datetime.fromisoformat(time))
    result = dict()
    if kcurve_str is None:
        result['status'] = "NOK"
    else:
        result['status'] = "OK"
        result['timestamp'] = time
        result['def'] = kcurve_str
    return result


if __name__ == '__main__':
    # long story
    # i want to run this so that it can serve other PCs (not just local host)
    # to do this i need one thing
    # - has to run via fingals python install viz C:\Program Files\Nomura\Fingal64\Python\Python311 (orochi hack)
    # but alas fingal ships with empty websockets module which confuses the hell out of uvicorn which
    # it tries to load support for websockets, so i stub it out here by setting it to none.
    uvicorn.run("snapper:app", host="0.0.0.0", port=5006, reload=False, ws=None)
