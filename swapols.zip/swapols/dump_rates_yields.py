from finglib.bind import fpx
from finglib.date import date_from_excel
import datetime
import numpy as np
import pickle
import argparse
import re
import glob

def load_usdmkt_for(mktname, dt):
    objs_to_load = ['Bond', 'BondPrice', 'BondFuture']
    fingal_set_data = ['usdh15ff.hst.SetData', 'USD:1m:1m.SetData', 'USD:3m:3m.SetData', 'USD:SOFR.SetData']

    fmkt = fpx().MktLoadFromDatabase(mktname, dt, "EODKC-US",  "NGFP-NY-OIS", "USD.KCurve",  objs_to_load, True, 'BuildLoadedObjectsAndPrecedentsOnly')
    fpx().MktSetDealDate(fmkt, dt)
    #set fixings 
    fpx().MktSetDataLoad(fmkt, fingal_set_data)
    return fmkt

    
def extract_swp_rates(fmkt, 	d_swp_insts):
    indices = {}
    xrates = {}

    for fwdcrvgrp in d_swp_insts:
        print(f"for fwdcrvgrp = {fwdcrvgrp}")
        n_spot_starting_ins = 0
        n_fwd_starting_ins = 1
        ridx = {}
        cidx = {'None': 0, 'spot': 0}
        for swp in d_swp_insts[fwdcrvgrp]:
            st, end = swp
            if st is None:
                ridx[end] = n_spot_starting_ins
                n_spot_starting_ins = n_spot_starting_ins + 1
            else:   
                if st in cidx:
                    continue
                cidx[st] = n_fwd_starting_ins
                n_fwd_starting_ins = n_fwd_starting_ins + 1

        swp_rate_matrix = np.zeros( (len(ridx), len(cidx)) )
        swp_delta_matrix = np.zeros( (len(ridx), len(cidx)) )
        xrates[fwdcrvgrp] = (ridx, cidx, swp_rate_matrix, swp_delta_matrix)
          

        for swp in d_swp_insts[fwdcrvgrp]:
            st, end = swp
            (rate, delta) = fpx().KCurveParSwapCoupon(fmkt+ 'USD.KCurve',  fwdcrvgrp, st, end)
            cc = cidx[st] if st is not None else 0
            rr = ridx[end]
            swp_rate_matrix[(rr,cc)] = rate[0]
            swp_delta_matrix[(rr,cc)] = delta[0]
            
            print(f">>>	{st}, {end }=> rate:{rate[0]} -> sens:{delta[0]}")
            
    return xrates
	
	
def extract_bond_yields(fmkt):

    mkt_prefix = fpx().MktInfo(fmkt, "MarketName")
    
    # get the list of on the run bonds from the curve!
    other_info2 = fpx().KCurveInfo("M_USD.KCurve", "OtherInfo2BuildArg")
    otr_bonds = fpx().ReadInfoItem(other_info2, "BondIssues")
	
    # get the full list of bonds from the market
    all_bonds = fpx().MktList("M",None, "Bond")
    # best effort filter for treasuries
    all_bonds = [ mkt_prefix + b[0]  for b in all_bonds if b[0].startswith('T ') or b[0].startswith('WIT ') ]
	
    # extract otr_bonds from all_bonds matching on cusip
    all_bonds_cusips = fpx().BondInfo(all_bonds, 'CUSIPCode')
    all_bonds_cusips = [ c[0] for c in all_bonds_cusips ]
    
    # cusips are the 2nd entry in otr bonds
    # extract tuples of (otr bond securty_name, cusips)
    relevant_otr_bonds= [ (all_bonds[all_bonds_cusips.index(b[1])], b) for b in otr_bonds ]
    
    #extract prices/yields
    xbondinfo = []
    xyields = {}
    
    bond_attrs = ['Yield', 'CleanPrice', 'DirtyPrice']
    nd_yields = np.zeros( (len(relevant_otr_bonds),  len(bond_attrs)) )
    ridx = {}
    cidx = { attr: i for i, attr in enumerate(bond_attrs) }    
    xyields['prc'] = (ridx, cidx, nd_yields)
    xyields['ust'] = xbondinfo
    
    i = 0
    
    for  bond_security_code, otr_bond_info2 in relevant_otr_bonds:
        otry, cusip, coupon, maturity = otr_bond_info2
        short_code = bond_security_code[len(mkt_prefix):]
        
        xbondinfo.append( (otry, short_code, cusip, coupon, maturity) )
        
        priceinfo= fpx().MktStandardisedInfo(mkt_prefix,  short_code,  bond_attrs)
        yld, cprice, dprice = priceinfo[0]
        
        ridx[otry] = i
        nd_yields[ (i, 0) ] = yld
        nd_yields[ (i, 1) ] = cprice
        nd_yields[ (i, 2) ] = dprice
                
        i = i +1
	
    return xyields
    
    
def persist_swap_data(outdir, dt, xrates):
    dumpdir = outdir + "\\"  + dt.strftime('%Y%m%d') 
    xfile = '_xrates.npy'
    np.save(dumpdir + xfile, xrates)
        

def persist_bond_data(outdir, dt, byields):
    print(f'Saving bond yields/prices...')
    dumpdir = outdir + "\\" + dt.strftime('%Y%m%d')
    xfile = '_byields.npy'
    np.save(dumpdir + xfile, byields)
        
    
# return the dates for which data exists for the corresponding suffix
def dump_data_exists(outdir, file_suffix):
    dumpdir = outdir + '\\'+ '*' + file_suffix
    files = glob.glob(dumpdir)
    regx = re.compile(r'.*(\d{4}\d{2}\d{2})' + file_suffix)
    
    file_dates = []
    for f in files:
        ismatched = regx.match(f)
        if not ismatched is None:
            dt = datetime.date.fromisoformat(ismatched.group(1))
            file_dates.append(dt)
        
    return file_dates
    
    
        
def x_rate(xrates, fwdcrvgrp, st, end):
    ridx, cidx, matrix, _ = xrates[fwdcrvgrp]
    st = 'None' if st is None else st
    end = 'None' if end is None else end
    rr = ridx[end]
    cc = cidx[st]
    return matrix[(rr,cc)] 
    

def b_idx(byields,  otry):
    ridx, cidx, matrix = byields['prc']
    if not otry in ridx:
        return None
    return  ridx[otry]
    
def b_yld(byields,  attr, otry):
    ridx, cidx, matrix = byields['prc']
    rr = b_idx(byields, otry)
    cc = cidx[attr]
    return matrix[(rr,cc)]     
    
def b_info(byields,  otry):
    binfo = byields['ust']
    rr = b_idx(byields, otry)
    return binfo[rr]     

    
            
if __name__ == '__main__':
    dswps = { 'sofr': [ \
        (None, '1y'), (None, '2y'),(None, '3y'), (None, '4y'),(None, '5y'), (None, '6y'),(None, '7y'), (None, '8y'),(None, '9y'), (None, '10y'), \
        (None, '11y'), (None, '12y'),(None, '13y'), (None, '14y'),(None, '15y'), (None, '16y'),(None, '17y'), (None, '18y'),(None, '19y'), (None, '20y'), \
        (None, '21y'), (None, '22y'),(None, '23y'), (None, '24y'),(None, '25y'), (None, '26y'),(None, '27y'), (None, '28y'),(None, '29y'), (None, '30y'), \
        (None, '35y'), (None, '40y'), (None, '45y'),(None, '50y'),\
        ('1y', '1y'),\
        ( '2y', '1y'), ( '2y', '2y'), ( '2y', '3y'), ( '2y', '5y'), ( '2y', '10y'),\
        ('3y','1y'), ('3y','2y'), ('3y','3y'), ('3y','5y'), ('3y', '10y'),\
        ('4y', '1y'), ('4y', '2y'), ('4y', '3y'), ('4y', '5y'),\
        ('5y','1y'), ('5y','2y'), ('5y','3y'), ('5y','5y'), ('5y','10y'),\
        ( '6y','1y'), ( '6y','2y'), ( '6y','3y'), \
        ('7y','1y'), ('7y','2y'), ('7y','3y'),  \
        ('8y','1y'), ('8y','2y'), ('8y','3y'), ('8y','4y'), ('8y','5y'),\
        ('9y','1y'),  ('9y','2y'), ('9y','3y'), ('9y','5y'), \
        ('10y','1y'), ('10y','2y'), ('10y','3y'), ('10y','4y'), ('10y','5y'), ('10y','10y'), ('10y','15y'), ('10y','20y'),\
        ('11y','1y'),  ('11y','2y'), ('11y','3y'),  ('11y','4y'), \
        ('12y','3y'), \
        ('13y','2y'),  \
        ( '14y','1y'), \
        ('15y','1y'), ('15y','5y'), ('15y','10y'), ('15y','15y'),\
        ('16y','1y'), \
        ('17y','1y'),  \
        ('18y','1y'), \
        ('19y','1y'),  \
        ('20y','1y'), ('20y','5y'), ('20y','10y'),  \
        ( '25y','1y'), ( '25y','5y'), ( '25y','10y'), \
        ( '30y','5y'), ( '30y','10y'), ( '30y','20y'),\
        ('35y','5y'), ( '35y','10y'),( '35y','15y') \
    ] }
    

    prev_biz_day = fpx().PrevBizDay2(datetime.datetime.today(), 1, 'NY')
    prev_biz_day = date_from_excel(prev_biz_day)
    
    arghandler = argparse.ArgumentParser(prog='dump_rates_yields.py',  \
                        description='dump history for swap/bonds from  the eod markets in fingal')
    arghandler.add_argument('-o', '--outdir', required=True,  default='.')
    arghandler.add_argument('-s', '--start', default=prev_biz_day, type=datetime.date.fromisoformat)
    arghandler.add_argument('-e', '--end', default=prev_biz_day, type=datetime.date.fromisoformat)
    arghandler.add_argument('--objs', choices = ['swaps', 'bonds', 'all'], default='all')
    arghandler.add_argument('--overwrite', type=bool, default=False, action=argparse.BooleanOptionalAction)
    
    argx = arghandler.parse_args()
    
    start_bd = argx.start
    end_bd = argx.end
    
    objs_to_save = argx.objs
    
    print(f'{start_bd}, {end_bd}, {objs_to_save}')
    
    if argx.overwrite is False:
        swap_dumps_exist = dump_data_exists(argx.outdir, "_xrates.npy")
        bond_dumps_exist = dump_data_exists(argx.outdir, "_byields.npy")
       
       
    dt = end_bd
    while dt >= start_bd:
        
        while not fpx().IsBizDay(dt):
            dt = fpx().PrevBizDay2(dt, 1, 'NY')
            
        dt = date_from_excel(dt)
        
        # by default we load and overwrite
        load_required = True
        if argx.overwrite is False:
            if objs_to_save == 'all':
                if dt in swap_dumps_exist and dt in bond_dumps_exist:
                    load_required = False

            elif objs_to_save == 'swaps':
                if dt in swap_dumps_exist:
                    load_required = False
            
            elif objs_to_save == 'bonds' :
                if dt in bond_dumps_exist:
                    load_required = False
            
        
        if load_required is True:
            print(f'Loading market for date = { dt.strftime("%d%b%Y") }')
            fmkt = load_usdmkt_for("M", dt)
            
            if objs_to_save == 'swaps' or  objs_to_save == 'all':
                print(f'Extracting swap rates...')
                xrates= extract_swp_rates(fmkt,  dswps)
                print(f'Saving swap rates...')
                persist_swap_data(argx.outdir, dt, xrates)
            
            if objs_to_save == 'bonds' or  objs_to_save == 'all':
                print(f'Extracting bond yields...')
                byields = extract_bond_yields(fmkt)
                # persist bond data
                print(f'Saving swap rates...')
                persist_bond_data(argx.outdir, dt, byields)

                    
            fpx().MktRemove("M")
        
            #-----------------------------------------------------------------------
            print(f'Saving complete for  {dt.strftime("%d%b%Y") }')
            
        else:
            print(f'Dumps already exist for {dt.strftime("%d%b%Y")} . skipping...')
        
        dt = fpx().PrevBizDay2(dt, 1, 'NY')
        dt = date_from_excel(dt)
        
    #unxrates = np.load(dumpdir + xfile, None, True).item()
        
    #for fwdcrvgrp in dswps:
    #    for st,end in dswps[fwdcrvgrp]:
    #        print(f"{st}-> {end} => {x_rate(unxrates, fwdcrvgrp, st, end)}")
    
    dt = start_bd
    dumpdir = argx.outdir + "\\" + dt.strftime('%Y%m%d')
    xfile = '_byields.npy'
    unb = np.load(dumpdir + xfile, None, True).item()

    
    for otry in ['2Y', '5Y', '10Y']:
        print(f"{otry}-> {b_yld(unb,'Yield', otry)}")
