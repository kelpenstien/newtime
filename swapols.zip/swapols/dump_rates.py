from finglib.bind import fpx
from finglib.date import date_from_excel
import datetime
import numpy as np
import pickle


def load_usdkcurve_for(mktname, dt):
	objs_to_load = ['Bond', 'BondPrice', 'BondFuture']
	fmkt = fpx().MktLoadFromDatabase(mktname, dt, "EODKC-US",  "NGFP", "USD.KCurve",  objs_to_load, 'Smart', 'BuildLoadedObjectsAndPrecedentsOnly')
	fpx().MktSetDealDate(fmkt, dt)
	return fmkt

    
def extract_swp_rates(fmkt, 	d_swp_insts):
    indices = {}
    xrates = {}

    for fwdcrvgrp in d_swp_insts:
        print(f"for fwdcrvgrp = {fwdcrvgrp}")
        n_spot_starting_ins = 0
        n_fwd_starting_ins = 1
        ridx = {}
        cidx = {'None': 0, 'spot': 0}
        for swp in d_swp_insts[fwdcrvgrp]:
            st, end = swp
            if st is None:
                ridx[end] = n_spot_starting_ins
                n_spot_starting_ins = n_spot_starting_ins + 1
            else:   
                if st in cidx:
                    continue
                cidx[st] = n_fwd_starting_ins
                n_fwd_starting_ins = n_fwd_starting_ins + 1

        swp_rate_matrix = np.zeros( (len(ridx), len(cidx)) )
        swp_delta_matrix = np.zeros( (len(ridx), len(cidx)) )
        xrates[fwdcrvgrp] = (ridx, cidx, swp_rate_matrix, swp_delta_matrix)
          

        for swp in d_swp_insts[fwdcrvgrp]:
            st, end = swp
            (rate, delta) = fpx().KCurveParSwapCoupon(fmkt+ 'USD.KCurve',  fwdcrvgrp, st, end)
            cc = cidx[st] if st is not None else 0
            rr = ridx[end]
            swp_rate_matrix[(rr,cc)] = rate[0]
            swp_delta_matrix[(rr,cc)] = delta[0]
            
            print(f">>>	{st}, {end }=> rate:{rate[0]} -> sens:{delta[0]}")
            
    return xrates
    
    
def x_rate(xrates, fwdcrvgrp, st, end):
    ridx, cidx, matrix, _ = xrates[fwdcrvgrp]
    st = 'None' if st is None else st
    end = 'None' if end is None else end
    rr = ridx[end]
    cc = cidx[st]
    return matrix[(rr,cc)] 
        
            
if __name__ == '__main__':
    dswps = { 'sofr': [ \
        (None, '1y'), (None, '2y'),(None, '3y'), (None, '4y'),(None, '5y'), (None, '6y'),(None, '7y'), (None, '8y'),(None, '9y'), (None, '10y'), \
        (None, '11y'), (None, '12y'),(None, '13y'), (None, '14y'),(None, '15y'), (None, '16y'),(None, '17y'), (None, '18y'),(None, '19y'), (None, '20y'), \
        (None, '21y'), (None, '22y'),(None, '23y'), (None, '24y'),(None, '25y'), (None, '26y'),(None, '27y'), (None, '28y'),(None, '29y'), (None, '30y'), \
        (None, '35y'), (None, '40y'), \
        ('1y', '1y'),\
        ( '2y', '1y'), ( '2y', '2y'),\
        ('3y','1y'), ('3y','2y'), ('3y','3y'), \
        ('4y', '1y'), ('4y', '2y'), ('4y', '3y'), \
        ('5y','1y'), ('5y','2y'), ('5y','3y'), ('5y','5y'), \
        ( '6y','1y'), ( '6y','2y'), ( '6y','3y'), \
        ('7y','1y'), ('7y','2y'), ('7y','3y'),  \
        ('8y','1y'), ('8y','2y'), ('8y','3y'), \
        ('9y','1y'),  \
        ('10y','1y'), ('10y','5y'), ('10y','10y'), \
        ('11y','1y'),  ('11y','2y'), ('11y','3y'),  ('11y','4y'), \
        ('12y','3y'), \
        ('13y','2y'),  \
        ( '14y','1y'), \
        ('15y','1y'), ('15y','5y'),  \
        ('16y','1y'), \
        ( '17y','1y'),  \
        ('18y','1y'), \
        ('19y','1y'),  \
        ('20y','1y'), ('20y','5y'), ('20y','10y'),  \
        ( '25y','1y'), ( '25y','5y'), ( '25y','10y'), \
        ( '30y','5y'), ( '30y','10y'),  \
        ('35y','5y') \
    ] }
    
    
    start_bd = datetime.date(2022,1,1)
    end_bd = datetime.date(2024,1,25)
    
    dt = start_bd
    while dt < end_bd:
        
        while not fpx().IsBizDay(dt):
            dt = fpx().NextBizDay(dt, 1, 'NY')
            
        dt = date_from_excel(dt)
    
        fmkt = load_usdkcurve_for("M", dt)
        xrates= extract_swp_rates(fmkt,  dswps)
        byields= extract_bnd_yields(fmkt,  dswps)
        fpx().MktRemove("M")
        
        
        dumpdir = 'c:\\temp\\projects\\spd\\dat\\' + dt.strftime('%d%b%Y') 
        xfile = '_xrates.npy'
        np.save(dumpdir + xfile, xrates)
        
        
        dt = fpx().NextBizDay(dt, 1, 'NY')
        dt = date_from_excel(dt)
        
    #unxrates = np.load(dumpdir + xfile, None, True).item()
        
    #for fwdcrvgrp in dswps:
    #    for st,end in dswps[fwdcrvgrp]:
    #        print(f"{st}-> {end} => {x_rate(unxrates, fwdcrvgrp, st, end)}")
            
        
