from enum import Enum
import http.server
import urllib.parse as request_parse

import matplotlib.pyplot as mplt
from datetime import date
import swap_regressor

today = date.today()


datadir = "C:\\Temp\\projects\\spd\\dat\\ts"
pltgui = None


def regress_showplot(ins_desc, multivariate_factors=None):
    global pltgui
    if pltgui is None:
        pltgui = PyplotHttpServer()

    pltgui.plot(ins_desc)
    

def endgui():
    global pltgui
    if pltgui is None:
        return "NOT RUNNING"

    pltgui.shutdown()
    return "SHUTDOWNOK"

    
class PyplotHttpHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, request, client_address, server):
        self.regressor = server.regressor
        self.pp = server.plotter
        super().__init__(request, client_address, server)

    def do_GET(self):
        dget_attrs = request_parse.parse_qs(request_parse.urlparse(self.path).query)
    
        self.send_response(200)
        self.end_headers()
        
        try:
        
            if len(dget_attrs) <= 0:
                return
                
            if "ins_desc" not in dget_attrs:
                return
            lins_desc = dget_attrs["ins_desc"]
            if len(lins_desc) > 0:
                ins_desc = lins_desc[0]
            if ins_desc is None or len(ins_desc) == 0:
                return 
            
                
            multivariate_factors = dget_attrs["multivariate_factors"] if "multivariate_factors" in dget_attrs else None
            
            mvfactors = None
            if multivariate_factors is not None and len(multivariate_factors) > 0:
                mvfactors = multivariate_factors.split(",")

            self.pp.clear()
                
            trade_mid_history = swap_regressor.generate_historical_ts_for_trade(today, ins_desc, self.regressor)
            #multivariate factors
            intercept_slopes, projected, residuals = self.regressor.multifit(trade_mid_history, mvfactors)

            self.pp.plot_historics(221, ins_desc, trade_mid_history, projected)
            self.pp.plot_residuals(222, residuals)

            # regress the best fit
            intercept_slopes, projected, residuals, best_fit_key = self.regressor.bestfit(trade_mid_history)

            self.pp.plot_historics(223, ins_desc + " vs " + best_fit_key, trade_mid_history, projected)
            self.pp.plot_residuals(224, residuals)
                
            self.pp.show()	
        except Exception as exp:
            pass
        
    
    
class PyplotHttpService(http.server.HTTPServer):

    def __init__(self, address, port, historic_regressor, pyplotter):
        self.regressor = historic_regressor
        self.plotter = pyplotter
        
        super().__init__((address, port), PyplotHttpHandler)
        print("PyplotHttpService init **OK**")

    def start(self):
        self.serve_forever(poll_interval = 0.1) 
        
    def service_actions(self):
        self.plotter.flush_uievents()
        
    def shutdown(self):
        self.shutdown() 
        

        
if __name__ == '__main__':

    regressor = swap_regressor.HistoricRegressor(datadir)
    plotter = swap_regressor.PeterPlotter(datadir)



    hs = PyplotHttpService("localhost", 8080, regressor, plotter)
    hs.start()
    