from enum import Enum
from datetime import date
import matplotlib.pyplot as mplt
import numpy as np
import finglib.bind
import finglib.err

class FPtr:
    fpx=None
    @classmethod
    def get(cls):
        if cls.fpx is None:
            cls.fpx = finglib.bind.fpx()
        return cls.fpx

class SwapTypes(Enum):
    SWAP=1
    CURVE=2
    FLY=3
    CONDOR=4
    
def convert_mnemonic_date_to_date(dtstr, today):
    imm_prefix = ['f','g','h','j','k','m','n','q','u','v','x','z']
    
    fpx = FPtr.get()
    
    dt = None
    try:
        dt = fpx.ParseDate(dtstr, "mm/dd/yyyy")
    except finglib.err.FingalError as exp:
        # was not a date, how about a imm mnemonic?
        if dtstr[0] in imm_prefix:
            dt = fpx.NextImmDate(fpx.ParseContractName(dtstr, "ContractMonth"))
        # or perhaps a tenor?
        elif is_tenor(dtstr):
            dt = fpx.ParseInterval(dtstr, today, None, "Unadj", "S")

    return dt


def is_tenor(dtstr):
    #dealing with a tenor just return as is...
    return True if dtstr[-1] in ['d','m','y'] else False
    
    
def snap_to_tenor_grid(dt, today):    
    if dt is None:
        return None

    fpx = FPtr.get()        

    tenors = [ str(y) + "y" for y in range(40) ]
    tenor_dates = [ fpx.ParseInterval(tenor, today, None, "Unadj", "S") for tenor in tenors ]
    tenors_intervals = list( zip(tenor_dates, tenor_dates[1:]) )
    for start_interval, end_interval in tenors_intervals:
        if dt > start_interval and dt <= end_interval:
            if abs(start_interval - dt) < abs(end_interval - dt):
                return tenors[tenor_dates.index(start_interval)]
            else:
                return tenors[tenor_dates.index(end_interval)]
    return None

    
def normalize_ins_descriptor(today, desc):
    normlegs = []
    
    
    legs = desc.split("-")
    for leg in legs:
        is_fwd = False
        if leg.find("x") > 0:
            is_fwd = True
            tkns = leg.split("x")
        elif leg.index("y") > 0:
            at = leg.index("y") + 1
            first = leg[:at]
            second = leg[at:]
            # handle a edge case like 5y-7y-9y -> this generates leg with (7y, "") - we want this to be represented as [None, 7y]
            if second == "":
                tkns =  [ None, first ]
            else:
                is_fwd = True
                tkns = [first, second]
            
        s = "None"
        e = "None"
        
        if len(tkns) > 1:
            s,e = tkns
        else:
            s = None
            e = tkns[0]

        if not s is None:
            if is_tenor(s):
                stenor = s
            else:
                dt = convert_mnemonic_date_to_date(s, today)
                stenor = snap_to_tenor_grid(dt, today)
                if stenor == '0y':
                    stenor = None
                    is_fwd = False
                    
        else:
            stenor = None

        if not e is None:
            if is_tenor(e):
                etenor = e
            else:
                dt = convert_mnemonic_date_to_date(e, today)
                etenor = snap_to_tenor_grid(dt, today)
        
        normlegs.append( (is_fwd, (stenor, etenor)) )
    
    return normlegs

    
def infer_swap_type(norm_legs):
    nlegs = len(norm_legs)
    if nlegs== 4:
            type = SwapTypes.CONDOR
            weights = (-1, -2, 2, 1)
    elif nlegs == 3:
            type = SwapTypes.FLY
            weights = (-1, 2, -1)
    elif nlegs == 2:
            type = SwapTypes.CURVE
            weights = (-1, 1)
    elif nlegs == 1:
            type = SwapTypes.SWAP
            weights = (1,)

    return (type, weights)
    

class HistoricRegressor:
    @staticmethod
    def fkey(f, is_fwd=False):
        if len(f) == 1:
            return f[0]
        elif is_fwd is True:
            return f[0] + "x" + f[1]
        else:
            f = [ "None" if tenor is None else tenor for tenor in f]
            return "_".join(f)
            
    def __init__(self, dir, start_date=None, end_date=None):
        self.datadir = dir
        self.sd = start_date
        self.ed = end_date
        self.cache = {}
        
        self.factors = [
            ['2y'], ['5y'], ['7y'], ['10y'], ['20y'], ['30y'], 
            ['2y', '5y'], ['2y', '10y'],  ['2y', '30y'], ['5y', '10y'], ['5y', '30y'], ['10y', '30y'], 
            ['2y', '5y', '10y'], ['5y', '7y', '10y'], ['5y', '10y', '30y']
        ]
        
       
        self._2y = np.load(self.datadir +   "\\sofr_None_2y.npy", None, True)
        self._5y = np.load(self.datadir +   "\\sofr_None_5y.npy", None, True)
        self._7y = np.load(self.datadir +   "\\sofr_None_7y.npy", None, True)
        self._10y = np.load(self.datadir + "\\sofr_None_10y.npy", None, True)
        self._20y = np.load(self.datadir + "\\sofr_None_20y.npy", None, True)
        self._30y = np.load(self.datadir + "\\sofr_None_30y.npy", None, True)
        
        
        self.cache = { 
            "2y": self._2y,  
            "5y": self._5y, 
            "7y": self._7y, 
            "10y": self._10y, 
            "20y": self._20y, 
            "30y": self._30y 
        }
        
        for f in self.factors:
            if len(f) == 2:
                f1, f2 = f
                fkey = HistoricRegressor.fkey(f)
                self.cache[fkey] = (self.cache[f2] - self.cache[f1])*100
            elif len(f) == 3:
                f1, f2, f3 = f
                fkey = HistoricRegressor.fkey(f)
                self.cache[fkey] = (-self.cache[f1] + 2 * self.cache[f2] - self.cache[f3]) * 100
        
        #multivariate factor defaults....
        self.multivariate_factor_defaults = ['2y', '5y', '10y', '30y']
        self.defaultA = np.vstack( [np.ones(len(self._2y)), self._2y, self._5y, self._10y, self._30y] )
       

    def get_leg_history(self, leg_info):
        (is_fwd, (s, e)) = leg_info
        #s = "None" if s is None else s
        #cachekey = s + "_" + e
        cachekey = HistoricRegressor.fkey((s,e), is_fwd)
        if cachekey in self.cache:
            return self.cache[cachekey]

        absfile = self.datadir + "\\sofr_" + str(s) + "_" + e + ".npy"
        legdata = np.load(absfile, None, True)
        self.cache[cachekey] = legdata
        return legdata
        
        
    def multifit(self, trade_mid_history, factors = None):
        if factors == None or len(factors) == 0:
            factors = self.multivariate_factor_defaults
            A = self.defaultA
        else:
            A = np.vstack[np.ones(len(self._2y))]
            for f in factors:
                A = np.vstack([A, self.cache[f]])
        
    
        res,_,_,_ = np.linalg.lstsq(A.T, trade_mid_history, rcond=None)
        
        c = res[0] # y-intercept
        sf = [0.0] * len(factors)
        # extract the slope factors
        for i, f in enumerate(factors):
            sf[i]= res[i+1]
        
        projected = c 
        # extract the slope and the name of the corresponding time series.
        for slope, f in zip(sf, factors):
            projected = projected + slope * self.cache[f]
        
        residuals = trade_mid_history - projected
        return (res, projected, residuals)
        
        
        
    def bestfit(self, trade_mid_history):
        corr_vs_factors = []
        
        # find best corrlation with trade_mid_history
        for f in self.factors:
            fk = HistoricRegressor.fkey(f)
            factor_ts = self.cache[fk]
            corr_pct = np.corrcoef(factor_ts, trade_mid_history)[0,1] * 100
            corr_vs_factors.append(corr_pct)
            

        print(self.factors)
        print(corr_vs_factors)
            
        highest_corr_pct = max(corr_vs_factors)
        lowest_corr_pct = min(corr_vs_factors)
        best_corr_pct = highest_corr_pct if abs(highest_corr_pct) >= abs(lowest_corr_pct) else lowest_corr_pct
        best_fit_factor = self.factors[corr_vs_factors.index(best_corr_pct)]
        best_fit_fk = HistoricRegressor.fkey(best_fit_factor)
        
        A = np.vstack([np.ones(len(self._2y)), self.cache[best_fit_fk]])
        res,_,_,_ = np.linalg.lstsq(A.T, trade_mid_history, rcond=None)
        # extract the intercept/slope factors
        c, sf = res    

        projected = c + sf * self.cache[best_fit_fk]
        residuals = trade_mid_history - projected
        return (res, projected, residuals, f"{best_fit_fk}\n  beta=({sf:.3f}) corr={best_corr_pct:.2f}%")
    
    
        
def generate_historical_ts_for_trade(today, ins_desc, historic_regressor):
    norm_legs = normalize_ins_descriptor(today, ins_desc)
    (swap_type, weights) = infer_swap_type(norm_legs)
    
    hts = None
    try:
        for w, leg in zip(weights, norm_legs):
            d = historic_regressor.get_leg_history(leg)
            hts = w*d if hts is None else hts + (w*d)
        hts = hts * 100
    except Exception as exp:
        print(f"Error trying to get historic data for leg: {leg}. Skipping...")
        return None
    return hts
    

        
class PeterPlotter:

    def __init__(self, datadir):
        self.dts = np.load(datadir +   "\\dates.npy", None, True)
        self.fig = mplt.figure()
        self.subplots = []
        
    def clear(self):
        
        for ax in self.subplots:
            ax.clear()
            ax.remove()
        self.subplots.clear()
        
        if len(mplt.get_fignums()) == 0:
            self.fig = mplt.figure()
        

        
    def plot_historics(self, plotloc, ins_desc, hts, pts):
        ax = self.fig.add_subplot(plotloc)
        self.subplots.append(ax)
        
        color = 'tab:red'
        ax.set_xlabel('time (s)')
        ax.set_ylabel('level (bps)', color=color)
        live_plot = ax.plot(self.dts, hts, color=color, label='live')

        color = 'tab:green'
        prj_plot = ax.plot(self.dts, pts, color=color, label='projected')
        ax.tick_params(axis='y', labelcolor=color)
        ax.legend(handles=[live_plot, prj_plot], labels=['live', 'projected'], title=ins_desc, loc=4, fontsize='small', fancybox=True)

    def plot_residuals(self, plotloc, residuals):

        ax = self.fig.add_subplot(plotloc)
        self.subplots.append(ax)

        color = 'tab:blue'
        ax.set_ylabel('residual (bps)', color=color)  # we already handled the x-label with ax1
        ax.plot(self.dts, residuals, color=color)
        ax.tick_params(axis='y', labelcolor=color)
        ax.hlines(y=0, xmin = self.dts[0], xmax=self.dts[-1], color='r', linestyles='dotted')     
        
    def show(self):
        self.fig.tight_layout()
        mplt.show(block=False)
        
    def flush_uievents(self):
        if self.fig is None:
            return
        self.fig.canvas.flush_events()
        
    
if __name__ == '__main__':

    today = date.today()
    datadir = "..\\dat\\ts"
    regressor = HistoricRegressor(datadir)
    pp = PeterPlotter(datadir)
    
    while True:

        print("enter instrument short code descriptor....? ")
        ins_desc = input()
        
        if ins_desc is None or len(ins_desc.strip()) <=0:
            print("No useful input... try again ?")
            continue
        
        print("enter multivariate independent variables (default(4f) = 2y,5y,10y,30y)....? ")
        independent_variables = input()
        
        if not independent_variables is None and len(independent_variables.strip()) > 0:
            multivariate_factors = independent_variables.split(",")
        else:
            multivariate_factors = None
        
        
        print("enter univariate independent variable (best)....? ")
        independent_variable = input()
        
        if independent_variable is None or len(independent_variable.strip()) <= 0:
            univariate_factors = ['best']
        else:
            univariate_factors = independent_variable.split(",")

        trade_mid_history = generate_historical_ts_for_trade(today, ins_desc, regressor)
        if trade_mid_history is None:
            continue
            
        intercept_slopes, projected, residuals = regressor.multifit(trade_mid_history, multivariate_factors)
        
        pp.clear()
        pp.plot_historics(221, ins_desc, trade_mid_history, projected)
        pp.plot_residuals(222, residuals)
        
        # regress the best fit
        intercept_slopes, projected, residuals, best_fit_key = regressor.bestfit(trade_mid_history)

        pp.plot_historics(223, ins_desc + " vs " + best_fit_key, trade_mid_history, projected)
        pp.plot_residuals(224, residuals)
        
        pp.show()
        