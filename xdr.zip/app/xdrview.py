from textual.app import App, ComposeResult
from rich.text import Text
from textual.widgets import Footer, Label, RichLog, DataTable, TextArea, Input, Switch, Button, Rule
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.containers import HorizontalGroup, VerticalGroup, Vertical, HorizontalScroll, VerticalScroll
from textual import events
from textual.widgets import data_table

import os
import sys
import winsound
import datetime
import argparse
import traceback

from modelview import UIModel, SearchModel, SettingsModel
from filter import EventFilter
from xdrtypes import PackageType


class ChunkyBanner(HorizontalGroup):
    def __init__(self, ui_model, classes=None):
        self.ui_model = ui_model
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        for i in range(0, 6):
            yield Vertical(
                Label("", classes="banner_desc", id="banner_desc_" + str(i)),
                Label("", classes="banner_lvl", id="banner_lvl_" + str(i)),
                Label("", classes="banner_tm", id="banner_tm_" + str(i)),
                classes="banner_info", id=f"banner_info_" + str(i)
            )

    def update_css_class_based_on_size(self, banner_info, evt):
        class_suffix = min(int(evt.dv01 / (self.ui_model.big_boy_limit / 2)), 5)
        update_class = f"banner_style{class_suffix}"
        banner_info.set_classes(update_class)

    def update(self, evt_q):
        now = datetime.datetime.now(tz=datetime.timezone.utc)
        for i, evt in enumerate(self.ui_model.get_top_n_bigboys(6)):
            desc = self.query_one("#banner_desc_" + str(i))
            desc.update(evt.description)
            lvl = self.query_one("#banner_lvl_" + str(i))
            lvl.update(f"{evt.dv01}k @ {evt.get_formatted_lvl()}")
            tm = self.query_one("#banner_tm_" + str(i))
            stylized_tm = Text.assemble(evt.get_formatted_direction_hint(), f'     +{evt.get_elapsed_time(now)}分')
            tm.update(stylized_tm)
            # update styles
            banner_info = self.query_one("#banner_info_" + str(i))
            self.update_css_class_based_on_size(banner_info, evt)

    def on_click(self, event: events.Click) -> None:
        wgt_id = event.widget.id
        at = wgt_id.rfind("_")
        if at == -1:
            return
        i = int(wgt_id[at+1:])
        classifyId = self.ui_model.vm_bigboys[i] if i < len(self.ui_model.vm_bigboys) else None
        if classifyId is None:
            return
        xdrtbl = self.app.query_one(XDRPkgTable)
        xdrtbl.jump_to_row_by_key(classifyId)


class Spreadoz(HorizontalScroll):
    def __init__(self, ui_model, classes=None):
        self.ui_model = ui_model
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        for i, sprd_mne in enumerate(UIModel.sprds_of_interest):
            yield Vertical(
                Label(sprd_mne, classes="sprd_desc", id="sprd_desc_" + str(i)),
                Label("", classes="sprd_lvl", id="sprd_lvl_" + str(i)),
                Label("", classes="sprd_tm", id="sprd_tm_" + str(i)),
                classes="spread_info")

    def update(self, evt_q):
        now = datetime.datetime.now(tz=datetime.timezone.utc)
        for i, sprd_mne in enumerate(UIModel.sprds_of_interest):
            evt = self.ui_model.get_sprd_at_loc(i)
            if evt is None:
                self.clear(i)
                continue
            lvl = self.query_one("#sprd_lvl_" + str(i))
            lvl.update(f"{evt.dv01}k  {evt.get_formatted_lvl()}")
            tm = self.query_one("#sprd_tm_" + str(i))
            tm.update(f"{self.ui_model.vm_sprds_running_dv01[i]}k    +{evt.get_elapsed_time(now)}分")

    def clear(self, i):
        lvl = self.query_one("#sprd_lvl_" + str(i))
        lvl.update("")
        tm = self.query_one("#sprd_tm_" + str(i))
        tm.update(f"{self.ui_model.vm_sprds_running_dv01[i]}k    +0分")

    def on_click(self, event: events.Click) -> None:
        wgt_id = event.widget.id
        if wgt_id is None:
            return;
        at = wgt_id.rfind("_")
        if at == -1:
            return
        i = int(wgt_id[at+1:])
        classifyId = self.ui_model.vm_sprds[i]
        if classifyId is None:
            return
        xdrtbl = self.app.query_one(XDRPkgTable)
        xdrtbl.jump_to_row_by_key(classifyId)


class ChunkyFlys(VerticalGroup):
    def __init__(self, ui_model, classes=None):
        self.ui_model = ui_model
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        for i, fly_mne in enumerate(UIModel.flys_of_interest):
            alternator = '_odd' if i % 2 != 0 else ''
            yield HorizontalGroup(
                Label(fly_mne, classes="fly_desc" + alternator, id="fly_desc_" + str(i)),
                Label("", classes="fly_lvl" + alternator, id="fly_lvl_" + str(i)),
                Label("", classes="fly_dv01" + alternator, id="fly_dv01_" + str(i))
            )

    def fmt_lvl(self, evt):
        prefix = str(evt.dv01) + 'k'
        len_postfix = 13 - len(prefix)
        return f'{prefix}{evt.get_formatted_lvl():>{len_postfix}}'

    def update(self, evt_q):
        for i, fly_mne in enumerate(UIModel.flys_of_interest):
            evt = self.ui_model.get_fly_at_loc(i)
            if evt is None:
                self.clear(i)
                continue
            lvl = self.query_one("#fly_lvl_" + str(i))
            lvl.update(self.fmt_lvl(evt))
            total_dv01 = self.query_one("#fly_dv01_" + str(i))
            total_dv01.update(f"{int(self.ui_model.vm_flys_running_dv01[i])}k")

    def clear(self, i):
        lvl = self.query_one("#fly_lvl_" + str(i))
        lvl.update("")
        total_dv01 = self.query_one("#fly_dv01_" + str(i))
        total_dv01.update(f"{int(self.ui_model.vm_flys_running_dv01[i])}k")

    def on_click(self, event: events.Click) -> None:
        wgt_id = event.widget.id
        at = wgt_id.rfind("_")
        if at == -1:
            return
        i = int(wgt_id[at+1:])
        classifyId = self.ui_model.vm_flys[i]
        if classifyId is None:
            return
        xdrtbl = self.app.query_one(XDRPkgTable)
        xdrtbl.jump_to_row_by_key(classifyId)


class ChunkyCrvs(VerticalGroup):
    def __init__(self, ui_model, classes=None):
        self.ui_model = ui_model
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        for i, crv_mne in enumerate(UIModel.crvs_of_interest):
            alternator = '_odd' if i % 2 != 0 else ''
            yield HorizontalGroup(
                Label(crv_mne, classes="crv_desc" + alternator, id="crv_desc_" + str(i)),
                Label("", classes="crv_lvl" + alternator, id="crv_lvl_" + str(i)),
                Label("", classes="crv_dv01" + alternator, id="crv_dv01_" + str(i))
            )

    def fmt_lvl(self, evt):
        prefix = str(evt.dv01) + 'k'
        len_postfix = 13 - len(prefix)
        return f'{prefix}{evt.get_formatted_lvl():>{len_postfix}}'

    def update(self, evt_q):
        for i, crv_mne in enumerate(UIModel.crvs_of_interest):
            evt = self.ui_model.get_crv_at_loc(i)
            if evt is None:
                self.clear(i)
                continue
            lvl = self.query_one("#crv_lvl_" + str(i))
            lvl.update(self.fmt_lvl(evt))
            total_dv01 = self.query_one("#crv_dv01_" + str(i))
            total_dv01.update(f"{int(self.ui_model.vm_crvs_running_dv01[i])}k")

    def clear(self, i):
        lvl = self.query_one("#crv_lvl_" + str(i))
        lvl.update("")
        total_dv01 = self.query_one("#crv_dv01_" + str(i))
        total_dv01.update(f"{int(self.ui_model.vm_crvs_running_dv01[i])}k")

    def on_click(self, event: events.Click) -> None:
        wgt_id = event.widget.id
        at = wgt_id.rfind("_")
        if at == -1:
            return
        i = int(wgt_id[at+1:])
        classifyId = self.ui_model.vm_crvs[i]
        if classifyId is None:
            return
        xdrtbl = self.app.query_one(XDRPkgTable)
        xdrtbl.jump_to_row_by_key(classifyId)


class XDRPkgTable(DataTable):
    def __init__(self, ui_model, classes=None):
        self.ui_model = ui_model
        self.l_col_keys = None
        self.l_row_keys = list()
        super().__init__(classes=classes)

    XDRPKG_TABLE_JUSTIFICATION = [
        "left", "left", "right", "right", "right", "right", "right"
    ]

    XDRPKG_TABLE_STYLES = [
        "bold #03AC13", "bold #03AC13", "italic #03AC13", "bold #03AC13", "bold #03AC13", "bold #03AC13", "#03AC13"
    ]

    def on_mount(self) -> None:
        styled_header_columns = [Text(str(cell)) for cell in self.ui_model.XDRPKG_TABLE_COLUMNS]
        self.l_col_keys = self.add_columns(*styled_header_columns)
        self.cursor_type = "row"

    def push_row(self, classifyId, styled_row):
        self.add_row(*styled_row, key=classifyId)
        self.l_row_keys.append(classifyId)

    def pop_row(self, classifyId):
        self.remove_row(row_key=classifyId)
        self.l_row_keys.remove(classifyId)

    def update(self, evt_q):
        auto_scroll = self.app.is_interactive_mode
        for (classifyId, already_exists) in evt_q:
            row = self.ui_model.get_table_data(classifyId)
            # this is a signal to remove the corresponding classify_id
            if row is None and classifyId in self.l_row_keys:
                self.pop_row(classifyId)
                continue
            elif row is None:
                continue

            # Adding styled and justified `Text` objects instead of plain strings.
            pkg_type_color_code = PackageType.color_code(row[1])
            XDRPkgTable.XDRPKG_TABLE_STYLES[1] = f"bold {pkg_type_color_code}"
            styled_row = [
                Text(str(cell), style=style, justify=justify)
                for i, (cell, style, justify) in enumerate(
                    zip(row, XDRPkgTable.XDRPKG_TABLE_STYLES, XDRPkgTable.XDRPKG_TABLE_JUSTIFICATION)
                )
            ]
            if classifyId in self.l_row_keys:
                self.pop_row(classifyId)
            self.push_row(classifyId, styled_row)

        if auto_scroll is False:
            self.action_scroll_bottom()

    def full_refresh(self, col_index_of_updated_filter):
        if col_index_of_updated_filter is None:
            return
        try:
            l_classifyIds = self.ui_model.process_event_filter()
        except Exception as exp:
            print(f"Error trying to apply the filter for the given column. Ignoring. error msg = {exp}")
            print(traceback.print_exc())
            return
        self.clear(columns=True)

        styled_header_columns = [Text(str(cell), style=f"{self.ui_model.get_filter_col_style(i)}")
                                 for i, cell in enumerate(self.ui_model.XDRPKG_TABLE_COLUMNS)]
        self.l_col_keys = self.add_columns(*styled_header_columns)

        for classifyId in l_classifyIds:
            row = self.ui_model.get_table_data(classifyId)
            if row is None:
                continue
            # Adding styled and justified `Text` objects instead of plain strings.
            pkg_type_color_code = PackageType.color_code(row[1])
            XDRPkgTable.XDRPKG_TABLE_STYLES[1] = f"bold {pkg_type_color_code}"
            styled_row = [
                Text(str(cell), style=style, justify=justify)
                for i, (cell, style, justify) in enumerate(
                    zip(row, XDRPkgTable.XDRPKG_TABLE_STYLES, XDRPkgTable.XDRPKG_TABLE_JUSTIFICATION)
                )
            ]
            self.add_row(*styled_row, key=classifyId)
        self.l_row_keys.clear()
        self.l_row_keys.extend(l_classifyIds)

    def on_click(self, event: events.Click) -> None:
        # only responding to double clicks....
        if event.chain != 2:
            return
        if self.active_row != self.cursor_row:
            return
        if self.active_key is not None:
            markdown_deets = self.ui_model.get_deets(self.active_key)
            self.app.show_deets(markdown_deets)

    def on_data_table_row_selected(self, active_row: DataTable.RowSelected):
        self.active_key = active_row.row_key.value
        self.active_row = active_row.cursor_row

    def on_data_table_header_selected(self, header_selected: DataTable.HeaderSelected):
        col_index_selected = header_selected.column_index
        self.app.push_screen(DataTableColFilterInput(self.ui_model, col_index_selected, classes="filter_input"),
                             self.full_refresh)

    def jump_to_row_by_key(self, key):
        if key is None or len(key) == 0 or key == "":
            return
        # turn off auto scroll
        self.app.is_interactive_mode = True
        colkey_0 = self.l_col_keys[0]
        try:
            cell_coordinate = self.get_cell_coordinate(row_key=key, column_key=colkey_0)
        except data_table.CellDoesNotExist as exp:
            return
        self.move_cursor(row=cell_coordinate.row)
        self.app.refresh_bindings()


class DataTableColFilterInput(ModalScreen):
    def __init__(self, ui_model, col_index, classes=None):
        self.ui_model = ui_model
        self.col_index = col_index
        self.col_name = self.ui_model.XDRPKG_TABLE_COLUMNS[col_index]
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        yield HorizontalGroup(
            Input(type="text", placeholder=f"filter string for the column **{self.col_name}**", id="active_filter_input"),
            Button("OK (F9)", id="btn_ok"),
            Button("Cancel (ESC)", id="btn_cancel"),
            id="col_filter_input"
        )

    def on_mount(self, event: events.Mount) -> None:
        afi = self.query_one("#active_filter_input")
        filter = self.ui_model.filter_chain[self.col_index]
        if filter is None or filter.is_nop() is True:
            return
        afi.value = filter.clause

    def escape(self):
        self.app.pop_screen()

    def apply_filter(self):
        afi = self.query_one("#active_filter_input")
        col_index = self.ui_model.setup_event_filter(self.col_index, afi.value)
        self.dismiss(col_index)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn_cancel":
            self.escape()
        elif event.button.id == "btn_ok":
            self.apply_filter()

    def on_key(self, event: events.Key) -> None:
        if event.key == "escape":
            self.escape()
        elif event.key == "f9":
            self.apply_filter()


class SearchResultsTable(DataTable):
    def __init__(self, ui_model, classes=None, id=None):
        self.ui_model = ui_model
        self.l_col_keys = None
        super().__init__(classes=classes, id=id)

    XDRPKG_TABLE_STYLES = [
        ("bold #03AC13", "left"),
        ("bold #03AC13", "left"),
        ("italic #03AC13", "right"),
        ("bold #03AC13", "right"),
        ("bold #03AC13", "right"),
        ("bold #03AC13", "right"),
        ("#03AC13", "right")
    ]

    def on_mount(self) -> None:
        row_header = self.ui_model.XDRPKG_TABLE_COLUMNS
        self.l_col_keys = self.add_columns(*row_header)
        self.cursor_type = "row"

    def on_click(self, event: events.Click) -> None:
        if event.chain != 2:
            return
        if self.active_row != self.cursor_row:
            return
        if self.active_key is not None:
            markdown_deets = self.ui_model.get_deets(self.active_key)
            self.app.show_deets(markdown_deets)

    def on_data_table_row_selected(self, active_row: DataTable.RowSelected):
        self.active_key = active_row.row_key.value
        self.active_row = active_row.cursor_row

    def show_query_results(self, l_classifyIds):
        self.clear()
        for classifyId in l_classifyIds:
            row = self.ui_model.get_table_data(classifyId)
            if row is None:
                continue
            # Adding styled and justified `Text` objects instead of plain strings.
            pkg_type_color_code = PackageType.color_code(row[1])
            XDRPkgTable.XDRPKG_TABLE_STYLES[1] = f"bold {pkg_type_color_code}"
            styled_row = [
                Text(str(cell), style=style, justify=justify)
                for i, (cell, style, justify) in enumerate(
                    zip(row, XDRPkgTable.XDRPKG_TABLE_STYLES, XDRPkgTable.XDRPKG_TABLE_JUSTIFICATION)
                )
            ]
            self.add_row(*styled_row, key=classifyId)


class SearchView(ModalScreen):
    def __init__(self, ui_model, search_model, classes=None):
        self.ui_model = ui_model
        self.search_model = search_model
        super().__init__(classes=classes)

    sqlWhereClause = "where dv01 > 100;"

    def compose(self) -> ComposeResult:
        yield VerticalGroup(
            Label("***/***", classes="serchqueryid", id="searchqueryid"),
            TextArea(SearchView.sqlWhereClause, classes="searchquery", id="searchquery"),
            SearchResultsTable(self.ui_model, classes="searchresult", id="searchresult")
        )

    def on_mount(self, event: events.Mount) -> None:
        sq = self.query_one('#searchquery')
        sq.text = self.search_model.get_active_where_clause()
        sqid = self.query_one('#searchqueryid')
        sqid.update(self.search_model.get_display_label())

    def execute_search(self, where_clause):
        l_classifyId = self.ui_model.run_query(where_clause)
        if l_classifyId is None:
            return False
        elif len(l_classifyId) <= 0:
            return True
        search_result_tbl = self.query_one("#searchresult")
        search_result_tbl.show_query_results(l_classifyId)
        return True

    def on_key(self, event: events.Key) -> None:
        if event.key == 'f9':
            sq = self.query_one('#searchquery')
            where_clause = sq.text
            where_clause = where_clause.strip()
            if len(where_clause) < 5:
                return
            some_res_returned = self.execute_search(where_clause)
            if some_res_returned is False:
                return
            self.search_model.add_clause(where_clause)
            sqid = self.query_one('#searchqueryid')
            sqid.update(self.search_model.get_display_label())

        elif event.key == "shift+up":
            sql_clause = self.search_model.prev()
            sq = self.query_one('#searchquery')
            sq.text = sql_clause
            sqid = self.query_one('#searchqueryid')
            sqid.update(self.search_model.get_display_label())

        elif event.key == "shift+down":
            sql_clause = self.search_model.next()
            sq = self.query_one('#searchquery')
            sq.text = sql_clause
            sqid = self.query_one('#searchqueryid')
            sqid.update(self.search_model.get_display_label())

        elif event.key == 'escape':
            self.app.pop_screen()


class DeetsViewer(ModalScreen):
    def __init__(self, ui_model, deets_markdown, classes=None):
        self.ui_model = ui_model
        self.deets_markdown = deets_markdown
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        yield RichLog(highlight=True, markup=True, classes="deets", id="deets")

    def on_mount(self, event: events.Mount) -> None:
        log_viewer = self.query_one("#deets")
        log_viewer.write(self.deets_markdown)

    def on_key(self, event: events.Key) -> None:
        if event.key == "escape":
            self.app.pop_screen()


class SettingsView(ModalScreen):
    def __init__(self, ui_model, settings_model, classes=None):
        self.ui_model = ui_model
        self.model = settings_model
        super().__init__(classes=classes)

    def compose(self) -> ComposeResult:
        yield VerticalGroup(
            HorizontalGroup(
                Label("Scrolling Banner filter dv01 ", classes="setting_labels"),
                Input(type="integer", id="big_boy_filter_input")
            ),
            Rule(),
            HorizontalGroup(
                Label("Time Locale:            ", classes="setting_labels"),
                Label("local", classes="setting_labels"),
                Switch(value=True, id="time_locale_switch"),
                Label("utc", classes="setting_labels")
            ),
            Rule(),
            Button("Save Settings", id="save_settings")
        )

    def on_mount(self, event: events.Mount) -> None:
        bb = self.query_one('#big_boy_filter_input')
        bb.value = str(self.model.get_big_boy_limit())
        tl = self.query_one('#time_locale_switch')
        tl.value = self.model.time_display_is_utc()

    def save(self):
        bb = self.query_one('#big_boy_filter_input')
        self.model.set_big_boy_limit(bb.value)
        tl = self.query_one('#time_locale_switch')
        self.model.set_time_display(tl.value)
        self.model.save()
        self.app.pop_screen()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "save_settings":
            self.save()

    def on_key(self, event: events.Key) -> None:
        if event.key == 'f9':
            self.save()

        elif event.key == 'escape':
            self.app.pop_screen()


class XdrViewer(App):
    CSS_PATH = "xdrview.tcss"

    BINDINGS = [
        ("a", "auto_scroll", "AutoScroll"),
        ("s", "search", "Search"),
        ("z", "settings", "Settings"),
    ]

    # reactives
    evtq = reactive(list)
    # where we want to click around and interact with the app the scrolling stops.
    # you can restart it when you hit the auto scroll binding though
    is_interactive_mode = reactive(False)

    def watch_evtq(self, evt_q):
        if len(evt_q) == 0:
            return

        cb = self.query_one(ChunkyBanner)
        cb.update(evt_q)
        sprdoz = self.query_one(Spreadoz)
        sprdoz.update(evt_q)
        cfs = self.query_one(ChunkyFlys)
        cfs.update(evt_q)
        ccrv = self.query_one(ChunkyCrvs)
        ccrv.update(evt_q)
        cfs = self.query_one(XDRPkgTable)
        cfs.update(evt_q)
        # status bar
        statusbar = self.query_one("#statusbar")
        latest_classify_id, _ = evt_q[-1]
        statusbar.update(f"@{self.ui_model.d_evts[latest_classify_id].eventId}")

    def on_ready(self):
        self.xdr_event_worker = self.run_worker(self.ui_model.listen_to_xdr_events, "sqlevtlistener", exclusive=True, thread=True)

    def init_ui_model(self, sqlfile, hostname):
        self.ui_model = UIModel(self, sqlfile, hostname)
        self.ui_model.add_settings_model(self.settings_model)

    def init_search_model(self, search_config_file_path):
        self.search_model = SearchModel(self, search_config_file_path)

    def init_settings_model(self, settings_config_file_path):
        self.settings_model = SettingsModel(self, settings_config_file_path)

    def update_events(self, l_events):
        self.evtq.clear()
        self.evtq.extend(l_events)
        self.mutate_reactive(XdrViewer.evtq)

    def play_wav(self):
        winsound.PlaySound(self.settings_model.get_wav_file(), winsound.SND_ASYNC)

    def show_deets(self, deets_markdown):
        self.push_screen(DeetsViewer(self.ui_model, deets_markdown, classes="deets_viewer"))

    def apply_filter_refresh_table(self):
        pass

    def compose(self) -> ComposeResult:
        yield Footer(show_command_palette=False)

        bigboys = ChunkyBanner(self.ui_model, classes="banner")
        yield bigboys

        spreads = Spreadoz(self.ui_model, classes="spreadoz")
        yield spreads

        xdrtbl = XDRPkgTable(self.ui_model, classes="xdrtable")

        flys_crvs_vg = VerticalScroll(
            ChunkyFlys(self.ui_model, classes="flys"),
            ChunkyCrvs(self.ui_model, classes="crvs"),
            Label("......", classes="statusbar", id="statusbar"),
            classes="flyscurves"
        )
        yield HorizontalGroup(xdrtbl, flys_crvs_vg, classes="lowerhalf")

    def action_toggle_dark(self) -> None:
        """An action to toggle dark mode."""
        self.theme = (
            "textual-dark" if self.theme == "textual-light" else "textual-light"
        )

    def action_auto_scroll(self) -> None:
        self.is_interactive_mode = False
        self.refresh_bindings()

    def action_search(self) -> None:
        self.is_interactive_mode = True
        self.refresh_bindings()
        self.push_screen(SearchView(self.ui_model, self.search_model))

    def action_settings(self) -> None:
        self.refresh_bindings()
        self.push_screen(SettingsView(self.ui_model, self.settings_model))

    def check_action(self, action: str, parameters: tuple[object, ...]) -> bool | None:
        if action == "auto_scroll":
            if self.is_interactive_mode is True:
                return True
            else:
                return False
        return True

    def action_quit(self) -> None:
        if self.xdr_event_worker is not None:
            self.xdr_event_worker.cancel()
            self.xdr_event_worker = None
        self.app.exit()


def sqlite_init(sqlite_file_path, sqlite_file_name):
    sql_file = f"{sqlite_file_path}{sqlite_file_name}"
    if os.path.isfile(sql_file):
        print(f"{sql_file} already exists...will use this file")
        return sql_file
    else:
        print(f"{sql_file} does not exist...Aborting.")
        return None


if __name__ == "__main__":

    today = datetime.datetime.today()

    arghandler = argparse.ArgumentParser(prog='xdrview.py', description='SDR Viewer')
    arghandler.add_argument('-r', '--remote_data_path', default='y:\\AM\\NYC\\Rates\\Traders\\Swaps\\sheldon\\dtcc\\')
    arghandler.add_argument('-s', '--hostname', default=None, type=str)
    # start and end dates are inclusive >=start date and <= end date
    arghandler.add_argument('-t', '--asofdate', default=today, type=datetime.date.fromisoformat)
    arghandler.add_argument('-c', '--config_path', default='xdr\\')

    argx = arghandler.parse_args()

    asofdate = argx.asofdate
    dt_yyyy_mm_dd = asofdate.strftime("%Y_%m_%d")
    yyyy_mm_dd = asofdate.strftime("%Y-%m-%d")

    # where the processed data is saved and is shared between listeners on the network (good luck)
    remote_sqlite_file = None
    if argx.hostname is None:
        remote_data_file_path = argx.remote_data_path
        remote_sqlite_file_name = f"{dt_yyyy_mm_dd}.db"
        remote_sqlite_file = sqlite_init(remote_data_file_path, remote_sqlite_file_name)
        if remote_sqlite_file is None:
            sys.exit(0)

    config_file_path = os.environ['TEMP'] + "\\" + argx.config_path

    EventFilter.set_as_of_date(asofdate)

    app = XdrViewer()
    app.init_search_model(config_file_path)
    app.init_settings_model(config_file_path)
    app.init_ui_model(remote_sqlite_file, argx.hostname)

    app.run()
