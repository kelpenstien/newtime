import requests
import datetime
import time
import zipfile
import glob
import shutil
import traceback
import os
import sys
import argparse

import sqlite3
import csv

from collections import namedtuple

import sortedcontainers

from xdrtypes import PackageType, LevelType
from events import XDREvent
from trade import Trade
import swap_live_level

dtcc_url_prefix = 'https://pddata.dtcc.com/ppd/api/report/intraday/cftc/CFTC_SLICE_RATES_'


class SDRTree:
    def __init__(self, mkt_snapshot, timedelta_window_seconds=50):
        self.mkt_snap = mkt_snapshot
        self.tdw = timedelta_window_seconds

        # dict of 'node_ids' => "trade_data"
        self.id = {}
        # d[sef] -> d[lvl] -> [classifyId1, classifyId2, classifyId3,....]
        self.d = {}
        # d[classifyId] -> [oid1, oid2, oid3,....]
        self.d_classify = dict()

        # dict of new trade oids => "trade_data" recvd in this latest sequence
        self.nid = dict()
        # dict of new [(sef,lvl)] -> sortedlist[trd1, trd2,...]
        self.dxsl = dict()

        self.l_dirtybit = list()

        self.tear_here = "-" * 80
        self.eventId = -1

    def expand_pkglvls(self, t_sef_lvl):
        xl = sortedcontainers.SortedList(key=lambda trd: trd.evtDt)
        sef, lvl = t_sef_lvl
        if sef not in self.d:
            self.d[sef] = dict()

        d_pkglvls = self.d[sef]
        if lvl not in d_pkglvls:
            d_pkglvls[lvl] = list()
            return xl

        l_classifyIds = d_pkglvls[lvl]
        return SDRTree.expand_classifyIds(l_classifyIds, self.d_classify, self.id, xl)

    @staticmethod
    def expand_classifyIds(l_classifyIds, d_classify, d_trds, l_out=None):
        l = sortedcontainers.SortedList(key=lambda t: t.endDt) if l_out is None else l_out
        for classifyId in l_classifyIds:
            for oid in d_classify[classifyId]:
                trd = d_trds[oid]
                l.add(trd)
        return l

    def prep_trade_for_classification(self, t):
        oid = t.oid
        sef = t.platform_id
        lvl = t.lvl
        sl = (sef, lvl)

        # remove trades already seen
        if oid in self.nid:
            old_trade = self.nid[oid]
            old_sef = old_trade.platform_id
            old_lvl = old_trade.lvl
            old_sl = (old_sef, old_lvl)
            old_xsl = self.dxsl[old_sl]
            old_xsl.remove(old_trade)
        elif oid in self.id:
            old_trade = self.id[oid]
            old_sef = old_trade.platform_id
            old_lvl = old_trade.lvl
            old_sl = (old_sef, old_lvl)
            if old_sl in self.dxsl:
                old_xsl = self.dxsl[old_sl]
            else:
                old_xsl = self.expand_pkglvls(old_sl)
                self.dxsl[old_sl] = old_xsl
            old_xsl.remove(old_trade)

        # add trades never seen before
        if sl in self.dxsl:
            xsl = self.dxsl[sl]
        else:
            xsl = self.expand_pkglvls(sl)
            self.dxsl[sl] = xsl

        xsl.add(t)

        # at the end of function...
        self.nid[t.oid] = t

    # checks if trades are identical except for the timestamp


    def classify(self, remote_sql3conn):
        # augment self.nid with the oid of existing trades.
        for t_sef_lvl in self.dxsl:
            sef, lvl = t_sef_lvl
            xsl = self.dxsl[t_sef_lvl]
            for trd in xsl:
                if trd.oid not in self.nid:
                    self.nid[trd.oid] = trd

        # reclassifying one sef, lvl pair at a time
        for t_sef_lvl in self.dxsl:
            sef, lvl = t_sef_lvl
            xsl = self.dxsl[t_sef_lvl]
            print(f"classifying trades for sef {sef} @ {lvl}")

            last_active_evtDt = None
            for i, trd in enumerate(xsl):
                # work out which package a trade belongs to based on tdw.
                if last_active_evtDt is None:
                    classifyId = trd.build_classify_id()
                    last_active_evtDt = trd.evtDt
                    continue
                elif (trd.evtDt - last_active_evtDt).seconds < self.tdw:
                    last_trd = xsl[i - 1]
                    classifyId = trd.inherit_classify_id(last_trd)
                    continue
                else:
                    classifyId = trd.build_classify_id()
                    last_active_evtDt = trd.evtDt

            # rebuild the d_classifyIds and new_classifyIds for this package level.
            new_classifyIds = list()
            new_dc = dict()
            for trd in xsl:
                if trd.classifyId not in new_classifyIds:
                    new_classifyIds.append(trd.classifyId)
                    new_dc[trd.classifyId] = list([trd.oid])
                else:
                    new_ids = new_dc[trd.classifyId]
                    new_ids.append(trd.oid)

            # find out which packages changed or were newly added and only update those...
            # keep a list of packages which were removed because underlying trades were
            # bucketed into other packages....
            updated_classifyIds = frozenset(new_classifyIds)
            existing_classifyIds = frozenset(self.d[sef][lvl]) if sef in self.d and lvl in self.d[sef] else frozenset()

            removed_classifyIds = existing_classifyIds - updated_classifyIds
            common_classifyIds = updated_classifyIds & existing_classifyIds
            added_classifyIds = updated_classifyIds - existing_classifyIds

            # work out which classify ids are not in the new but in the old
            # so this is where a classifyId has simply dropped off....
            for classifyId in removed_classifyIds:
                new_dc[classifyId] = list()
                self.write_empty_event_to_db(remote_sql3conn, classifyId)

            # work out which classify ids are in both
            # but the underlying trades differ and write those to the database..
            for classifyId in common_classifyIds:
                l_existing_trades = SDRTree.expand_classifyIds([classifyId], self.d_classify, self.id)
                l_new_trades = SDRTree.expand_classifyIds([classifyId], new_dc, self.nid)
                if l_existing_trades == l_new_trades:
                    continue

                (pkg_type, l_per_leg_trds) = self.apply_adv_heuristics_classify_pkg(l_new_trades)
                self.process_classification(remote_sql3conn, classifyId, pkg_type, new_dc[classifyId], l_per_leg_trds)

            # work out which classify ids are brand new
            for classifyId in added_classifyIds:
                l_new_trades = SDRTree.expand_classifyIds([classifyId], new_dc, self.nid)
                (pkg_type, l_per_leg_trds) = self.apply_adv_heuristics_classify_pkg(l_new_trades)
                self.process_classification(remote_sql3conn, classifyId, pkg_type, new_dc[classifyId], l_per_leg_trds)

            self.d_classify = self.d_classify | new_dc
            self.d[sef][lvl] = new_classifyIds

        self.id = self.id | self.nid
        self.dxsl.clear()
        self.nid.clear()

    def process_classification(self, remote_sql3conn, classifyId, pkg_type, ids, l_leg_ids):
        if remote_sql3conn is not None:
            self.write_classification_to_db(remote_sql3conn, classifyId, pkg_type, ids, l_leg_ids)
        self.log_classification(classifyId, pkg_type, ids)

    def prep_max_eventId(self, sql3conn):
        sqlMaxEvent = """select max(eventId) from XDREVT"""

        try:
            cursor = sql3conn.cursor()
            res = cursor.execute(sqlMaxEvent)
            r = res.fetchone()
            if r is None:
                self.eventId = 1
                return
            self.eventId = 1 if r[0] is None else r[0]
            return
        except sqlite3.OperationalError as exp:
            print(f"Error getting the current max eventId from db")
            print(f"{traceback.print_exc()}")
        except sqlite3.IntegrityError as exp:
            print(f"Error getting the current max eventId from db")
            print(f"{traceback.print_exc()}")

    sqlDeets = """insert into DEETS values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
    sqlXDREvt = """insert into XDREVT values (?,?,?,?,?,?,?,?,?,?,?,?)"""
    sqlLastEventForClassifyId = """
        select * from XDREVT 
        where eventId = (
            select max(eventId) from XDREVT 
            where classifyId = ?
            )"""

    def write_empty_event_to_db(self, sql3conn, classifyId):
        try:
            cursor = sql3conn.cursor()
            res = cursor.execute(SDRTree.sqlLastEventForClassifyId, (classifyId,))
            cols = [desc[0] for desc in cursor.description]
            r = res.fetchone()
            if r is None:
                return False
            d_evt = {c: v for c, v in zip(cols, r)}
            evt = XDREvent(d_evt)
            t_XDREvt = (self.eventId, evt.classifyId, evt.ts, evt.sef, evt.type, evt.description, evt.moniker,
                        0, evt.lvl, evt.lvl_type.value, 0, None)
            cursor.execute(SDRTree.sqlXDREvt, t_XDREvt)
            self.eventId += 1
            return True

        except sqlite3.OperationalError as exp:
            print(f"Error saving down a empty event for classifyId = {classifyId}")
            print(f"{traceback.print_exc()}")
            return False
        except sqlite3.IntegrityError as exp:
            print(f"Error saving down a empty event for classifyId = {classifyId}")
            print(f"{traceback.print_exc()}")
            return False

    def write_deets_to_db(self, sql_cursor, classifyId, ids):
        t_n = list()
        for i, trd_id in enumerate(ids):
            t = self.nid[trd_id]
            dv01_leg = int(sum(t.risk) / 1000)
            t_n.append((self.eventId, classifyId, t.oid, t.notnl, t.startDt, t.endDt, t.start_snap, t.end_snap, t.tenor_snap,
                        t.fxd_rate_leg, t.sprd_leg, t.other_pymt_amt, t.lvl, t.lvl_type.value, dv01_leg))
        sql_cursor.executemany(SDRTree.sqlDeets, t_n)

    def write_classification_to_db(self, sql3conn, classifyId, type, ids, l_leg_ids):
        len_ids = len(ids)
        ta, tb, tc, tn = l_leg_ids
        len_0 = len(ta)
        t0 = ta[0]
        len_1 = len(tb)
        t1 = tb[0] if len_1 > 0 else None
        len_2 = len(tc)
        t2 = tc[0] if len_2 > 0 else None
        len_n = len(tn)

        ldf = '%.5f'
        if t0.lvl_type == LevelType.PRICE:
            ldf = '%.2f'
        elif type == PackageType.FLY or type == PackageType.CURVE:
            ldf = '%.4f'
        elif type == PackageType.SPREAD or type == PackageType.SPREAD_FLY or type == PackageType.SPREAD_SWITCH:
            ldf = '%.3f'
        elif type == PackageType.MULTI_LEG or type == PackageType.OUTRIGHT:
            ldf = '%.5f'

        ts = t0.evtDt.isoformat()
        sef = t0.platform_id
        lvl = t0.lvl
        lvl_type = t0.lvl_type
        description = None
        moniker = None
        dv01 = 0.0

        try:
            cursor = sql3conn.cursor()

            if len_n > 0:
                # multileg
                _, tbl = self.get_max_dv01(ta, tb, tc, tn)
                res_dv01 = self.get_fuzzy_dv01(ta, tb, tc, tn)
                description = f"{tbl.startDt} x {tbl.endDt} ...+ ({len_ids - 1})"
                dv01 = res_dv01

                self.write_deets_to_db(cursor, classifyId, ids)

            elif len_2 > 0:
                #3 legs
                (s0, e0, tenor0) = t0.dates_for_display()
                (s1, e1, tenor1) = t1.dates_for_display()
                (s2, e2, tenor2) = t2.dates_for_display()

                dv01_0 = self.get_dv01_totals(ta)
                dv01_1 = self.get_dv01_totals(tb)
                dv01_2 = self.get_dv01_totals(tc)

                if type == PackageType.INVOICE:
                    description = f"{t0.invoice_label()} . {t1.invoice_label()} . {t2.invoice_label()}"
                elif type == PackageType.MMS:
                    description = f"{t0.mms_label()} . {t1.mms_label()} . {t2.mms_label()}"
                elif type == PackageType.FOMC:
                    description = f"{t0.fomc_label()} . {t1.fomc_label()} . {t2.fomc_label()}"
                elif type == PackageType.SPREAD:
                    description = f"split spd {e0}"
                    moniker = f"{e0}"
                elif t0.is_spot_start and t1.is_spot_start and t2.is_spot_start:
                    description = f"{tenor0}.{tenor1}.{tenor2}"
                    moniker = description
                elif t0.startDt == t1.startDt and t1.startDt == t2.startDt:
                    description = f"{s1} / {tenor0}.{tenor1}.{tenor2}"
                else:
                    description = f"{s0}/{tenor0} . {s1}/{tenor1} . {s2}/{tenor2}"

                if type == PackageType.INVOICE:
                    dv01 = dv01_1
                elif type == PackageType.MMS:
                    dv01 = dv01_1
                elif type == PackageType.FOMC:
                    dv01 = dv01_1
                elif type == PackageType.FLY or type == PackageType.SPREAD_FLY:
                    dv01 = dv01_1
                elif type == PackageType.MULTI_LEG:
                    dv01 = self.get_fuzzy_dv01(ta, tb, tc)
                else:
                    dv01 = max(dv01_0, dv01_1, dv01_2)

                self.write_deets_to_db(cursor, classifyId, ids)

            elif len_1 > 0:
                # 2 legs
                (s0, e0, tenor0) = t0.dates_for_display()
                (s1, e1, tenor1) = t1.dates_for_display()
                dv01_0 = self.get_dv01_totals(ta)
                dv01_1 = self.get_dv01_totals(tb)

                if type == PackageType.INVOICE:
                    description = f"{t0.invoice_label()} . {t1.invoice_label()}"
                elif type == PackageType.MMS:
                    description = f"{t0.mms_label()} . {t1.mms_label()}"
                elif type == PackageType.FOMC:
                    description = f"{t0.fomc_label()} . {t1.fomc_label()}"
                elif type == PackageType.SPREAD:
                    description = f"split spd {e0}"
                    moniker = f"{e0}"
                elif t0.is_spot_start and t1.is_spot_start:
                    description = f"{tenor0}.{tenor1}"
                    moniker = description
                elif t0.startDt == t1.startDt:
                    description = f"{s0} / {tenor0}.{tenor1}"
                else:
                    description = f"{s0}/{tenor0} . {s1}/{tenor1}"

                if type == PackageType.INVOICE:
                    dv01 = dv01_1
                elif type == PackageType.MMS:
                    dv01 = dv01_1
                elif type == PackageType.FOMC:
                    dv01 = dv01_1
                elif type == PackageType.CURVE or type == PackageType.SPREAD_SWITCH:
                    dv01 = dv01_1
                elif type == PackageType.MULTI_LEG:
                    dv01 = self.get_fuzzy_dv01(ta, tb)
                else:
                    dv01 = max(dv01_0, dv01_1)

                self.write_deets_to_db(cursor, classifyId, ids)

            elif len_0 > 0 and \
                    (type == PackageType.SPREAD or
                     type == PackageType.OUTRIGHT or
                     type == PackageType.INVOICE or
                     type == PackageType.MMS or
                     type == PackageType.FOMC):
                # 1 leg
                (s0, e0, tenor0) = t0.dates_for_display()
                if type == PackageType.INVOICE:
                    description = f"{t0.invoice_label()}"
                elif type == PackageType.MMS:
                    description = f"{t0.mms_label()}"
                elif type == PackageType.FOMC:
                    description = f"{t0.fomc_label()}"
                elif type == PackageType.SPREAD:
                    description = f"{e0}"
                elif type == PackageType.OUTRIGHT:
                    if t0.is_spot_start:
                        description = f"{tenor0}"
                    elif t0.is_bkwd_start:
                        description = f"{s0} \\ {tenor0}"
                    else:
                        description = f"{s0} / {tenor0}"

                if s0 == "spot" and t0.is_end_exact:
                    moniker = f"{tenor0}"

                if type == PackageType.INVOICE:
                    dv01 = self.get_fuzzy_dv01(ta)
                elif type == PackageType.MMS:
                    dv01 = self.get_fuzzy_dv01(ta)
                elif type == PackageType.FOMC:
                    dv01 = self.get_fuzzy_dv01(ta)
                elif type == PackageType.OUTRIGHT:
                    dv01 = self.get_fuzzy_dv01(ta)
                elif type == PackageType.SPREAD:
                    dv01 = self.get_dv01_totals(ta)

                self.write_deets_to_db(cursor, classifyId, ids)

            direction_hint = self.guess_big_boy_direction(classifyId, type, ids, l_leg_ids, dv01)

            t_XDREvt = (self.eventId, classifyId, ts, sef, type, description, moniker,
                        len_ids, lvl, lvl_type.value, dv01, direction_hint)
            cursor.execute(SDRTree.sqlXDREvt, t_XDREvt)
            self.eventId += 1

        except sqlite3.OperationalError as exp:
            print(f"Error saving classified trade info {classifyId} to db")
            print(f"{traceback.print_exc()}")
            sql3conn.rollback()
        except sqlite3.IntegrityError as exp:
            print(f"Error saving classified trade info {classifyId} to db")
            print(f"{traceback.print_exc()}")
            sql3conn.rollback()

    def guess_big_boy_direction(self, classifyId, type, ids, l_leg_ids, dv01):
        # we only need to look at trades which are outright
        ta, tb, tc, tn = l_leg_ids
        if len(tb) > 0:
            return None
        if len(tc) > 0:
            return None
        if len(ta) != 1:
            return None
        if type != PackageType.OUTRIGHT:
            return None

        t = ta[0]
        if self.has_upfront(t):
            return None
        if dv01 <= 20:
            return None

        traded_lvl = t.fxd_rate_leg if abs(10-t.lvl) < 0.00001 else t.lvl

        live_mid = swap_live_level.get_swap_mid_as_of(self.mkt_snap, t.evtDt, t.startDt, t.endDt)
        if live_mid is None:
            return None

        return 'r' if traded_lvl <= live_mid else 'p'

    def get_dv01_totals(self, trades):
        return sum([int(sum(t.risk) / 1000) for t in trades])

    def get_max_dv01(self, *l_legs):
        dv01s = [(int(sum(t.risk) / 1000), t) for leg in l_legs for t in leg]
        return max(dv01s, key=lambda t: t[0])

    def _get_netted_dv01(self, *l_legs):
        dv01s = [int(sum(t.risk) / 1000) for leg in l_legs for t in leg]
        max01 = max(dv01s)
        rdv01 = max01
        dv01s.remove(max01)
        while len(dv01s) > 0:
            dv01 = max(dv01s)
            if rdv01 > 0:
                rdv01 -= dv01
            else:
                rdv01 += dv01
            dv01s.remove(dv01)
        return max01, rdv01

    def xxget_netted_dv01(self, *l_legs):
        dv01s = list()
        for l_trds in l_legs:
            l_trds.sort(key=lambda t: t.fxd_rate_leg)
            at_t = l_trds[0]
            dv01s.append(int(sum(at_t.risk) / 1000))
            for t in l_trds[1:]:
                if t.fxd_rate_leg != at_t.fxd_rate_leg:
                    at_t = t
                    dv01s.append(int(sum(t.risk) / 1000))
                else:
                    dv01s[-1] = dv01s[-1] + int(sum(t.risk) / 1000)

        max01 = max(dv01s)
        rdv01 = max01
        dv01s.remove(max01)
        while len(dv01s) > 0:
            dv01 = max(dv01s)
            if rdv01 > 0:
                rdv01 -= dv01
            else:
                rdv01 += dv01
            dv01s.remove(dv01)
        return max01, rdv01

    DV01Stats = namedtuple("DV01Stats", ['net', 'tot', 'max'])

    def get_dv01_stats(self, l_trds):
        dv01s = list()
        tot01 = 0
        for at_t in l_trds:
            dv01 = int(sum(at_t.risk) / 1000)
            tot01 += dv01
            dv01s.append(dv01)

        max01 = max(dv01s)
        rdv01 = self.get_netted_dv01(dv01s)
        return SDRTree.DV01Stats(rdv01, tot01, max01)

    def get_netted_dv01(self, l_dv01s):
        dv01s = l_dv01s.copy()
        max01 = max(dv01s)
        rdv01 = max01
        dv01s.remove(max01)
        while len(dv01s) > 0:
            dv01 = max(dv01s)
            if rdv01 > 0:
                rdv01 -= dv01
            else:
                rdv01 += dv01
            dv01s.remove(dv01)
        return rdv01

    def get_fuzzy_dv01(self, *l_legs):
        # list {tuple (netted 01, total 01, max 01)}
        l_01s = list()

        for l_trds in l_legs:
            dv01Info = self.get_dv01_stats(l_trds)
            l_01s.append(dv01Info)

        # more than 3 legs - real multi
        if len(l_legs) > 3:
            # this is a netting of per leg netted values...
            return self.get_netted_dv01([l01.net for l01 in l_01s])

        # more than 2 legs - can be a fly
        elif len(l_legs) > 2:
            info0 = l_01s[0]
            info1 = l_01s[1]
            info2 = l_01s[2]

            if info0.tot == info1.tot and info1.tot == info2.tot:
                return info0.tot
            elif abs(info0.tot - info1.tot) < 2 and abs(info1.tot - info2.tot) < 2:
                return info0.tot
            elif info0.net == info1.net and info1.net == info2.net:
                return info0.net
            elif abs(info0.net - info1.net) < 2 and abs(info1.net - info2.net) < 2:
                return info0.net
            else:
                netted_tot_dv01 = self.get_netted_dv01([l01.tot for l01 in l_01s])
                if abs(netted_tot_dv01) < 7:
                    return netted_tot_dv01
                else:
                    return self.get_netted_dv01([l01.net for l01 in l_01s])


        # more than 1 leg - can be a curve
        elif len(l_legs) > 1:
            info0 = l_01s[0]
            info1 = l_01s[1]
            if info0.tot == info1.tot:
                return info0.tot
            elif abs(info0.tot - info1.tot) < 2:
                return info0.tot
            elif info0.net == info1.net:
                return info0.net
            elif abs(info0.net - info1.net) < 2:
                return info0.net
            else:
                netted_tot_dv01 = self.get_netted_dv01([l01.tot for l01 in l_01s])
                if abs(netted_tot_dv01) < 7:
                    return netted_tot_dv01
                else:
                    return self.get_netted_dv01([l01.net for l01 in l_01s])

        else:
            info0 = l_01s[0]

            if -5 <= info0.net <= 5:
                return info0.net
            else:
                return info0.tot

    def fold(self, trds):
        trds_cpy = list(trds)
        res = (list(), list(), list(), list())

        at = 0
        while len(trds_cpy) > 0 and at < 3:
            l_matches = res[at]
            trd = trds_cpy[0]
            l_matches.append(trd)
            for otrd in trds_cpy:
                if trd == otrd:
                    continue
                if trd.startDt == otrd.startDt and trd.endDt == otrd.endDt:
                    l_matches.append(otrd)
            trds_cpy = [trd for trd in trds_cpy if trd not in l_matches]
            at += 1
        if len(trds_cpy) > 0:
            res[-1].extend(trds_cpy)
        return res

    def all_legs_spread_compatible(self, trds):
        for t in trds:
            if not t.is_spread_compatible:
                return False
        return True

    def all_legs_crvfly_compatible(self, trds):
        for t in trds:
            if not t.is_crvfly_compatible:
                return False
        return True

    def all_legs_invoice_compatible(self, trds):
        for t in trds:
            if not t.is_invoice_compatible:
                return False
        return True

    def all_legs_mms_compatible(self, trds):
        for t in trds:
            if not t.is_mms_compatible:
                return False
        return True

    def all_legs_fomc_compatible(self, trds):
        for t in trds:
            if not t.is_fomc_compatible:
                return False
        return True

    def all_start_dates_match(self, *legs):
        l_or_trd = legs[0]
        # first start date of the first trade or first trade of leg passed in
        startDt = l_or_trd[0].startDt if type(l_or_trd) is list else l_or_trd.startDt
        for l_or_trd in legs:
            if type(l_or_trd) is list:
                for trd in l_or_trd:
                    if trd.startDt != startDt:
                        return False
            else:
                if l_or_trd.startDt != startDt:
                    return False
        return True

    def all_end_dates_differ(self, *legs):
        l_end_dates = []
        for l_or_trd in legs:
            endDt = l_or_trd[0].endDt if type(l_or_trd) is list else l_or_trd.endDt
            if endDt in l_end_dates:
                return False
            else:
                l_end_dates.append(endDt)
        return True

    def apply_adv_heuristics_classify_pkg(self, trds):
        ta, tb, tc, tn = self.fold(trds)
        len_0 = len(ta)
        len_1 = len(tb)
        len_2 = len(tc)
        len_n = len(tn)

        pkg_type = None

        if len_n > 0:
            # more than 3 legs, so a multi trade....
            pkg_type = PackageType.MULTI_LEG

        elif len_2 > 0:
            # 3 legs
            if self.all_legs_invoice_compatible(trds):
                if self.all_end_dates_differ(ta, tb, tc):
                    pkg_type = PackageType.INVOICE
            elif self.all_legs_mms_compatible(trds):
                if self.all_end_dates_differ(ta, tb, tc):
                    pkg_type = PackageType.MMS
            elif self.all_legs_fomc_compatible(trds):
                if self.all_end_dates_differ(ta, tb, tc):
                    pkg_type = PackageType.FOMC
            elif self.all_legs_spread_compatible(trds):
                if self.all_start_dates_match(ta, tb, tc) and self.all_end_dates_differ(ta, tb, tc):
                    if self.is_rate_based_fly(ta, tb, tc) is True:
                        pkg_type = PackageType.FLY
                    else:
                        pkg_type = PackageType.SPREAD_FLY
                else:
                    pkg_type = PackageType.MULTI_LEG
            elif self.all_legs_crvfly_compatible(trds):
                if self.all_end_dates_differ(ta, tb, tc):
                    if self.is_rate_based_fly(ta, tb, tc) is True:
                        pkg_type = PackageType.FLY
                    else:
                        pkg_type = PackageType.MULTI_LEG
                else:
                    pkg_type = PackageType.MULTI_LEG
            else:
                pkg_type = PackageType.MULTI_LEG

        elif len_1 > 0:
            # 2 legs
            if self.all_legs_invoice_compatible(trds):
                if self.all_end_dates_differ(ta, tb):
                    pkg_type = PackageType.INVOICE
            elif self.all_legs_mms_compatible(trds):
                if self.all_end_dates_differ(ta, tb):
                    pkg_type = PackageType.MMS
            elif self.all_legs_fomc_compatible(trds):
                if self.all_end_dates_differ(ta, tb):
                    pkg_type = PackageType.FOMC
            elif self.all_legs_spread_compatible(trds):
                if self.all_start_dates_match(ta, tb) and self.all_end_dates_differ(ta, tb):
                    if self.is_rate_based_curve(ta, tb) is True:
                        pkg_type = PackageType.CURVE
                    else:
                        pkg_type = PackageType.SPREAD_SWITCH
                else:
                    pkg_type = PackageType.MULTI_LEG
            elif self.all_legs_crvfly_compatible(trds):
                if self.all_end_dates_differ(ta, tb):
                    if self.is_rate_based_curve(ta, tb) is True:
                        pkg_type = PackageType.CURVE
                    else:
                        pkg_type = PackageType.MULTI_LEG
                else:
                    pkg_type = PackageType.MULTI_LEG
            else:
                pkg_type = PackageType.MULTI_LEG

        elif len_0 > 0:
            # 1 legs (can have multiple pieces)
            if self.all_legs_invoice_compatible(trds):
                pkg_type = PackageType.INVOICE
            elif self.all_legs_mms_compatible(trds):
                pkg_type = PackageType.MMS
            elif self.all_legs_fomc_compatible(trds):
                pkg_type = PackageType.FOMC
            elif self.all_legs_spread_compatible(trds):
                pkg_type = PackageType.SPREAD
            else:
                pkg_type = PackageType.OUTRIGHT
        else:
            pkg_type = PackageType.MULTI_LEG

        return pkg_type, (ta, tb, tc, tn)

    def has_upfront(self, *trds):
        for trd in trds:
            if abs(trd.other_pymt_amt) != 0.0:
                return True
        return False

    def is_rate_based_fly(self, ta, tb, tc):
        # check that the rate on all the legs with the same start date is the same
        if not ta[0].fxd_rate_matches(ta[1:]):
            return False

        if not tb[0].fxd_rate_matches(tb[1:]):
            return False

        if not tc[0].fxd_rate_matches(tc[1:]):
            return False

        #  we try and work out if this is a rate based fly or curve....
        # to do that we work out the fly/curve level and see if it matches that package spread...
        # if it does - well it's probably a curve or fly _rate_ trade and not a spread. booya!
        t0 = ta[0]
        t1 = tb[0]
        t2 = tc[0]
        if t0.sprd_leg1 != 0.0 or t0.sprd_leg2 != 0.0 or \
                t1.sprd_leg1 != 0.0 or t1.sprd_leg2 != 0.0 or \
                t2.sprd_leg1 != 0.0 or t2.sprd_leg2 != 0.0:
            return False
        fly_level = 100 * (2 * t1.fxd_rate_leg - t0.fxd_rate_leg - t2.fxd_rate_leg)
        if abs(fly_level - t0.lvl) < 0.1 or abs(fly_level - t0.lvl / 100.0) < 0.1:
            return True

        return False

    def is_rate_based_curve(self, ta, tb):
        # check that the rate on all the legs with the same start date is the same
        if not ta[0].fxd_rate_matches(ta[1:]):
            return False

        if not tb[0].fxd_rate_matches(tb[1:]):
            return False

        #  we try and work out if this is a rate based fly or curve....
        # to do that we work out the fly/curve level and see if it matches that package spread...
        # if it does - well it's probably a curve or fly _rate_ trade and not a spread. booya!
        t0 = ta[0]
        t1 = tb[0]
        if t0.sprd_leg1 != 0.0 or t0.sprd_leg2 != 0.0 or \
                t1.sprd_leg1 != 0.0 or t1.sprd_leg2 != 0.0:
            return False
        curve_level = 100 * (t1.fxd_rate_leg - t0.fxd_rate_leg)
        if abs(curve_level - t0.lvl) < 0.1 or abs(curve_level - t0.lvl / 100.0) < 0.1:
            return True

        return False

    def log_classification(self, classifyId, type, ids):
        len_ids = len(ids)
        t0 = self.nid[ids[0]]
        t1 = self.nid[ids[1]] if len(ids) > 1 else None
        t2 = self.nid[ids[2]] if len(ids) > 2 else None

        ldf = '%.5f'
        if t0.lvl_type == LevelType.PRICE:
            ldf = '%.2f'
        elif type == PackageType.FLY or type == PackageType.CURVE:
            ldf = '%.4f'
        elif type == PackageType.SPREAD or type == PackageType.SPREAD_FLY or type == PackageType.SPREAD_SWITCH:
            ldf = '%.3f'
        elif type == PackageType.MULTI_LEG or type == PackageType.OUTRIGHT:
            ldf = '%.5f'

        print(f"time: {t0.evtDt.strftime('%H:%M:%S')}")
        print(f"{type} on {t0.platform_id} ")

        if len_ids == 3:
            (s0, e0, tenor0) = t0.dates_for_display()
            (s1, e1, tenor1) = t1.dates_for_display()
            (s2, e2, tenor2) = t2.dates_for_display()
            if t0.is_spot_start and t1.is_spot_start and t2.is_spot_start:
                print(f"    {e0} x {e1} x {e2} @ {ldf % t1.lvl}")
            elif t0.start_snap == t1.start_snap and t1.start_snap == t2.start_snap:
                print(f"    {s1} fx {tenor0} x {tenor1} x {tenor2} @ {ldf % t1.lvl}")
            else:
                print(f"    {s0} fx {tenor0} - {s1} fx {tenor1} - {s2} fx {tenor2} @ {ldf % t1.lvl}")

            if t0.other_pymt_amt != 0 or t1.other_pymt_amt != 0 or t2.other_pymt_amt != 0:
                print(f"up$     {t0.other_pymt_amt}   {t1.other_pymt_amt}   {t2.other_pymt_amt}")

            if type == PackageType.FLY or type == PackageType.SPREAD_FLY:
                print(f"dv01: {int(sum(t1.risk) / 1000)}k ")
            else:
                print(f"dv01: {int(max(sum(t0.risk), sum(t1.risk), sum(t2.risk)) / 1000)}k")

        elif len_ids == 2:
            (s0, e0, tenor0) = t0.dates_for_display()
            (s1, e1, tenor1) = t1.dates_for_display()
            if t0.is_spot_start and t1.is_spot_start:
                print(f"    {e0} x {e1} @ {ldf % t0.lvl} ")
            elif t0.start_snap == t1.start_snap:
                print(f"    {s0} fx {tenor0} x {tenor1} @ {ldf % t0.lvl}")
            else:
                print(f"    {s0} fx {tenor0} - {s1} fx {tenor1} @ {ldf % t0.lvl}")

            if t0.other_pymt_amt != 0 or t1.other_pymt_amt != 0:
                print(f"up$     {t0.other_pymt_amt}   {t1.other_pymt_amt}")

            if type == PackageType.CURVE or type == PackageType.SPREAD_SWITCH:
                print(f"dv01: {int(sum(t1.risk) / 1000)}k ")
            else:
                print(f"dv01: {int(max(sum(t0.risk), sum(t1.risk)) / 1000)}k")

        elif len_ids == 1:
            (s0, e0, tenor0) = t0.dates_for_display()
            if type == PackageType.SPREAD:
                print(f"    {e0} @ {ldf % t0.lvl}")
            elif type == PackageType.OUTRIGHT:
                if t0.is_spot_start:
                    print(f"{e0} @ {ldf % t0.lvl}")
                elif t0.is_bkwd_start:
                    print(f"<{s0}> x {tenor0} @ {ldf % t0.lvl}")
                else:
                    print(f"{s0} fx {tenor0} @ {ldf % t0.lvl}")

            if t0.other_pymt_amt != 0:
                print(f"up$ {t0.other_pymt_amt}")

            print(f"dv01: {int(sum(t0.risk) / 1000)}k")

        else:
            for i, trd_id in enumerate(ids):
                t = self.nid[trd_id]
                (s, e, tenor) = t0.dates_for_display()
                fixed_rate = t.fxd_rate_leg
                margin = t.sprd_leg
                upfront = t.other_pymt_amt
                print(
                    f"{s} x {e} @ {ldf % t.lvl}  r={fixed_rate} m={margin} up$={upfront} dv01:{int(sum(t.risk) / 1000)}k")

        print(self.tear_here)


def get_dtcc_slices(dtcc_cache_dir, start_at_seq, end_seq_num=-1):
    httpSession = requests.Session()
    httpSession.proxies = {
        'https': '185.46.212.90:80'
    }

    def exhaust_dtcc_slices(httpSession, start_seq_num, end_seq_num=-1):
        lzipFiles = glob.glob(f"{dtcc_cache_dir}{dt_yyyy_mm_dd}_*.zip")

        seq = start_seq_num
        while end_seq_num == -1 or seq < end_seq_num:

            dtcc_file_for_seq = f"{dtcc_cache_dir}{dt_yyyy_mm_dd}_{seq}.zip"
            if dtcc_file_for_seq in lzipFiles:
                print(f"Data for {dtcc_file_for_seq} exists.. skipping...")
                seq = seq + 1
                continue

            slice_url = "".join((dtcc_url_prefix, dt_yyyy_mm_dd, "_", str(seq), '.zip'))
            print(f"firing http *get*  => {slice_url}")
            try:
                resp = httpSession.get(slice_url, verify=False)
                if resp.status_code != 200:
                    break
            except requests.exceptions.ProxyError as pe:
                print(f"Error when trying to launch a get request -> {pe.strerror}.")
                print(f"Will try again.... in 10 seconds.")
                time.sleep(15)
                continue

            with open(dtcc_file_for_seq, "wb") as f:
                for chunky in resp.iter_content(chunk_size=1024):
                    f.write(chunky)

            # sleep every 10 requests for 3 seconds
            if seq % 10 == 0:
                time.sleep(3)

            seq = seq + 1

        return (start_seq_num, seq)

    seq = start_at_seq

    while True:
        start_end_seq = exhaust_dtcc_slices(httpSession, seq, end_seq_num)
        (start_seq, end_seq) = start_end_seq
        if start_seq != end_seq:
            yield start_end_seq
            seq = end_seq

        print("nothing to see here... sleeping z Z Z Z....")
        time.sleep(30)


def csv_from_slices(dtcc_cache_dir, dtcc_cache_zip_files_dir, start_end_seq, first_sequence):
    (start_seq, end_seq) = start_end_seq

    lzipFiles = glob.glob(f"{dtcc_cache_zip_files_dir}{dt_yyyy_mm_dd}_*.zip")
    # unzip all
    csvOutFile = f"{dtcc_cache_dir}dtcc_{dt_yyyy_mm_dd}.csv"

    csv_open_attr = "wb" if not os.path.isfile(csvOutFile) else "ab"

    with open(csvOutFile, csv_open_attr) as csvf:
        for seq in range(start_seq, end_seq):
            zip_file_name = f"{dtcc_cache_zip_files_dir}{dt_yyyy_mm_dd}_{seq}.zip"
            if zip_file_name in lzipFiles:
                unzip_append_csv(zip_file_name, seq, csvf, seq == first_sequence)

    return csvOutFile


def unzip_append_csv(zipf_name, seq, csvf_handl, add_header=False):
    def str_from_bytes_iter(byte_iterator):
        for b in byte_iterator:
            yield b.decode("utf-8")

    print(f"Trying to unzip {zipf_name}...")

    eol = bytes("\n", "utf-8")

    csvFileName = f"CFTC_SLICE_RATES_{dt_yyyy_mm_dd}_{seq}.csv"

    with zipfile.ZipFile(zipf_name) as zipf:
        with zipf.open(csvFileName) as f, zipf.open(csvFileName) as fcsv:
            fcsv_as_str = csv.reader(str_from_bytes_iter(fcsv))
            # skip header (unless asked to explicitly append it...)
            h = f.readline()
            _ = fcsv_as_str.__next__()

            h = h.rstrip() + b",SEQ" + eol
            if add_header is True:
                csvf_handl.write(h)

            for l, lcsv in zip(f, fcsv_as_str):
                if len(l) > 1:
                    if lcsv[21] != "USD" or lcsv[22] != "USD":
                        continue
                    if " vs" in lcsv[109]:
                        continue
                    pad_with_seqnum = f",{seq}"
                    l = l.rstrip() + bytes(pad_with_seqnum, "utf-8") + eol
                    csvf_handl.write(l)


def bcp_csv_sqlite(bulk_csv_file_name, sqlite_file_name, start_end_seq=None):
    print(f"bcp csv => sqlite ({sqlite_file_name})")

    if start_end_seq is not None:
        (start_seq, end_seq) = start_end_seq
    else:
        start_seq = 1

    sql3conn = sqlite3.connect(sqlite_file_name)

    with open(bulk_csv_file_name, 'r') as csvf:
        csvReader = csv.reader(csvf)
        lcols = next(csvReader)

        lcolsFormatted = [c.upper().replace(' ', '_').replace('-', '_').replace('/', '_') for c in lcols]
        insertSqlStmt = f"insert into SDR( {','.join(lcolsFormatted)} ) values ( {','.join('?' * len(lcolsFormatted))} )"

        num = 1
        cursor = sql3conn.cursor()
        for line in csvReader:
            seq = int(line[-1])
            if seq < start_seq:
                continue

            try:
                cursor.execute(insertSqlStmt, line)
                num = num + 1
            except sqlite3.OperationalError as exp:
                print(f"Error executing insertSqlStmt at line {num} msg: {traceback.print_exc()}")
                continue
        sql3conn.commit()


def sqlite_query_trade(sql3con, sql_query, t_start_end_seq):
    print(f"Runnnig query{sql_query} => sqlite {local_sqlite_file_name}")
    try:
        cursor = sql3con.cursor()

        res = cursor.execute(sql_query, t_start_end_seq)
        cols = [desc[0] for desc in cursor.description]

        while True:
            r = res.fetchone()
            if r is None:
                break

            d_trd = {c: v for c, v in zip(cols, r)}
            yield d_trd

    except sqlite3.OperationalError as exp:
        print(f"Error executing query {sql_query} against {local_sqlite_file_name}: {traceback.print_exc()}")


def sqlite_init(tmplt_sqlite_file_path, sqlite_file_path, sqlite_file_name):
    sql_file = f"{sqlite_file_path}{sqlite_file_name}"
    if os.path.isfile(sql_file):
        print(f"{sql_file} already exists...will use this file")
        return sql_file

    sql_file_tmplt = f"{tmplt_sqlite_file_path}tmplt.db"

    print(f"Coping file {sql_file_tmplt} --> {sql_file}")
    shutil.copyfile(sql_file_tmplt, sql_file)
    return sql_file


def try_to_commit(sql_conn, n_tries=50, sleepfor=5):
    i = 0
    while i < n_tries:
        try:
            sql_conn.commit()
            return True
        except sqlite3.OperationalError as exp:
            print(f"Error getting the current max eventId from db")
            print(f"{traceback.print_exc()}")
            time.sleep(sleepfor)
        except sqlite3.IntegrityError as exp:
            print(f"Error getting the current max eventId from db")
            print(f"{traceback.print_exc()}")
            time.sleep(sleepfor)
        i += 1
    return False


def sdr_query(yyyy_mm_dd):
    return f"""
    select 
        DISSEMINATION_IDENTIFIER, ORIGINAL_DISSEMINATION_IDENTIFIER,
        ACTION_TYPE,
        EVENT_TIMESTAMP, EXECUTION_TIMESTAMP, AMENDMENT_INDICATOR, 
        EFFECTIVE_DATE, EXPIRATION_DATE, PLATFORM_IDENTIFIER, BLOCK_TRADE_ELECTION_INDICATOR, 
        NOTIONAL_AMOUNT_LEG_1, NOTIONAL_AMOUNT_LEG_2, FIXED_RATE_LEG_1, FIXED_RATE_LEG_2, SPREAD_LEG_1, SPREAD_LEG_2, 
        FLOATING_RATE_RESET_FREQUENCY_PERIOD_LEG_1,  FLOATING_RATE_RESET_FREQUENCY_PERIOD_LEG_2,  
        FLOATING_RATE_RESET_FREQUENCY_PERIOD_MULTIPLIER_LEG_1,  FLOATING_RATE_RESET_FREQUENCY_PERIOD_MULTIPLIER_LEG_2,
        OTHER_PAYMENT_AMOUNT, OTHER_PAYMENT_TYPE,
        PACKAGE_INDICATOR, PACKAGE_TRANSACTION_PRICE, PACKAGE_TRANSACTION_PRICE_NOTATION, PACKAGE_TRANSACTION_SPREAD, PACKAGE_TRANSACTION_SPREAD_NOTATION, SEQ
    from 
        SDR 
    where 
        NOTIONAL_CURRENCY_LEG_1 = 'USD' and 
        NOTIONAL_CURRENCY_LEG_2 = 'USD' and  
        (
            (ACTION_TYPE in ('NEWT', 'MODI', 'CORR') and EVENT_TYPE = 'TRAD') or 
            (ACTION_TYPE = 'EROR' and EVENT_TYPE = '')
        ) 
        and       
        date(EXECUTION_TIMESTAMP) = '{yyyy_mm_dd}' and
        UPI_UNDERLIER_NAME not like '%vs%' and 
        UPI_FISN not like 'NA/O%' and
        SEQ >= ? and SEQ < ?
    """


if __name__ == '__main__':

    today = datetime.datetime.today()

    arghandler = argparse.ArgumentParser(prog='xdr.py',
                                         description='Scrape *SDR* repositories and persist relevant data to db')
    arghandler.add_argument('-l', '--local_data_path', default='c:\\temp\\dtcc\\')
    arghandler.add_argument('-r', '--remote_data_path', default='y:\\AM\\NYC\\Rates\\Traders\\Swaps\\sheldon\\dtcc\\')
    # start and end dates are inclusive >=start date and <= end date
    arghandler.add_argument('-t', '--asofdate', default=today.date(), type=datetime.date.fromisoformat)
    arghandler.add_argument('-s', '--ss', default=False, type=bool)
    arghandler.add_argument('-k', '--kdbcurve', default=False, type=bool)
    argx = arghandler.parse_args()

    asofdate = argx.asofdate
    dt_yyyy_mm_dd = asofdate.strftime("%Y_%m_%d")
    yyyy_mm_dd = asofdate.strftime("%Y-%m-%d")

    # where the raw data from the csvs are dumped.
    local_data_file_path = argx.local_data_path
    local_data_cache_dir = f"{local_data_file_path}{dt_yyyy_mm_dd}\\"
    local_sqlite_file_name = f"{dt_yyyy_mm_dd}.db"
    if os.path.isdir(f"{local_data_file_path}{dt_yyyy_mm_dd}") is False:
        os.mkdir(f"{local_data_file_path}{dt_yyyy_mm_dd}")
    local_sqlite_file = sqlite_init(local_data_file_path, local_data_file_path, local_sqlite_file_name)

    # where the processed data is saved and is shared between listeners on the network (good luck)
    remote_data_file_path = argx.remote_data_path
    remote_sqlite_file_name = f"{dt_yyyy_mm_dd}.db"
    if os.path.isdir(f"{remote_data_file_path}{dt_yyyy_mm_dd}") is False:
        os.mkdir(f"{remote_data_file_path}{dt_yyyy_mm_dd}")
    remote_sqlite_file = sqlite_init(local_data_file_path, remote_data_file_path, remote_sqlite_file_name)

    Trade.build_statics(asofdate, "c:\\temp\\projects\\xdr\\app\\mkt_static\\")

    if argx.kdbcurve is True:
        mkt_snapshot = swap_live_level.KDBMktSnapshot(local_data_file_path, asofdate)
    else:
        mkt_snapshot = swap_live_level.CurveWinderMktSnapshot(local_data_file_path, asofdate)
    tree = SDRTree(mkt_snapshot)

    sdrQuery = sdr_query(yyyy_mm_dd)

    first_sequence = 1
    with sqlite3.connect(local_sqlite_file) as l_sql3con, sqlite3.connect(remote_sqlite_file) as r_sql3con:
        last_seq = 1

        tree.prep_max_eventId(r_sql3con)
        i=1

        while True:
            # gets every dtcc
            for t_start_end_seq in get_dtcc_slices(local_data_cache_dir, first_sequence):
                print(f"Operating on seqences: {t_start_end_seq}")
                csvOutFile = csv_from_slices(local_data_file_path, local_data_cache_dir, t_start_end_seq,
                                             first_sequence)
                bcp_csv_sqlite(csvOutFile, f"{local_data_file_path}{local_sqlite_file_name}", t_start_end_seq)

                (s, e) = t_start_end_seq
                for seq in range(s, e):
                    classifying_start_end_seq = (seq, seq + 1)
                    print(f"{classifying_start_end_seq}")
                    for trd in sqlite_query_trade(l_sql3con, sdrQuery, classifying_start_end_seq):
                        t = Trade.make(trd)
                        if t.lvl is None:
                            continue
                        t.describe()
                        tree.prep_trade_for_classification(t)
                    tree.classify(r_sql3con)
                    try_to_commit(r_sql3con)
                i += 1

        sys.exit(0)

