from enum import Enum, StrEnum


class Direction(StrEnum):
    PAY = 'p'
    REC = 'r'
    NUL = ''

    @staticmethod
    def color_code(typ):
        return {
            Direction.PAY: 'white on #d90429',
            Direction.REC: 'white on #22577a',
            Direction.NUL: ''
        }[typ]


    @staticmethod
    def as_str(typ):
        return {
            Direction.PAY: 'PAY',
            Direction.REC: 'REC',
            Direction.NUL: ''
        }[typ]


class PackageType(StrEnum):
    OUTRIGHT = 'out'
    CURVE = 'crv'
    FLY = 'fly'
    SPREAD = 'spd'
    SPREAD_SWITCH = 'spdswx'
    SPREAD_FLY = 'spdfly'
    MULTI_LEG = 'multi'
    INVOICE = 'inv'
    MMS = 'mms'
    FOMC = 'fomc'

    @staticmethod
    def color_code(typ):
        return {
            PackageType.OUTRIGHT: 'white on #6a040f',
            PackageType.CURVE: 'white on #22577a',
            PackageType.FLY: 'white on #22577a',
            PackageType.SPREAD: 'white on #d90429',
            PackageType.SPREAD_SWITCH: 'white on #d90429',
            PackageType.SPREAD_FLY: 'white on #d90429',
            PackageType.MULTI_LEG: 'white on #132a13',
            PackageType.INVOICE: 'white on #be075a',
            PackageType.MMS: 'white on #868805',
            PackageType.FOMC: 'white on #ff00ff'
        }[typ]


class LevelType(Enum):
    RATE = 0
    PRICE = 1
    SPREAD = 2