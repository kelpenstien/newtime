import time
import requests


def fire_http_request(httpSession, url, params, try_again_on_failure=True, sleep_for=10, try_n_times=5):
    tries = 0
    print(f"calling => http://{url}/ ? with parans = {params}")
    while True:
        try:
            url_params = {'start': 1}
            resp = httpSession.get(url, params=params, verify=False)
            if resp.status_code != 200 and resp.status_code != 202:
                if try_again_on_failure:
                    tries += 1
                    continue
                else:
                    return None
            return resp
        except requests.exceptions.ProxyError as pe:
            print(f"Proxy Error when trying to launch a get request -> {pe.strerror}.")
            time.sleep(sleep_for)
            if try_again_on_failure:
                tries += 1
                continue
        except requests.exceptions.ConnectionError as pe:
            print(f"Connection Error when trying to launch a get request -> {pe.strerror}.")
            time.sleep(sleep_for)
            if try_again_on_failure:
                tries += 1
                continue
        except requests.exceptions.Timeout as pe:
            print(f"Timeout Error when trying to launch a get request -> {pe.strerror}.")
            time.sleep(sleep_for)
            if try_again_on_failure:
                tries += 1
                continue

        if try_again_on_failure:
            if tries < try_n_times:
                continue
            else:
                return None
        else:
            return None


