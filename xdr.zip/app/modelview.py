from collections import deque
import asyncio
import time
import sqlite3
import traceback
import requests
import json

from xdrtypes import PackageType, Direction
from events import XDREvent, Deets
from filter import EventFilter
from config import SearchQueryConfig, SettingsConfig
from config import get_wav_location
from http_requests_wrapper import fire_http_request

import textual.worker


class UIModel:

    sprds_of_interest = ["5y", "10y", "30y", "5y.10y", "10y.30y", "5y.30y", "20y", "7y",
                         "2y", "3y", "5y.10y.30y", "20y.30y"]

    crvs_of_interest = ["5y.10y", "10y.30y", "5y.30y", "20y.30y", "2y.10y", "2y.5y"]

    flys_of_interest = ["3y.4y.5y", "4y.5y.6y", "5y.6y.7y", "5y.7y.10y", "7y.8y.9y",
                        "8y.9y.10y", "10y.11y.12y", "10y.12y.15y", "10y.15y.30y",
                        "10y.20y.30y", "10y.15y.20y", "15y.20y.30y", "15y.20y.25y",
                        "20y.25y.30y", "2y.3y.5y", "2y.5y.10y"]

    def __init__(self, app_handle, sqlfile, server_hostname):
        self.sqlite_file = sqlfile
        self.sql3con = sqlite3.connect(self.sqlite_file) if sqlfile is not None else None

        # are we polling for events via the database or via http
        self.server_hostname = server_hostname

        # for example flys -> list([classifyId,...])
        self.d_flys = dict()
        self.vm_flys = ['']*len(UIModel.flys_of_interest)
        self.vm_flys_running_dv01 = [0.0]*len(UIModel.flys_of_interest)

        self.d_crvs = dict()
        self.vm_crvs = ['']*len(UIModel.crvs_of_interest)
        self.vm_crvs_running_dv01 = [0.0] * len(UIModel.crvs_of_interest)

        self.d_sprds = dict()
        self.vm_sprds = ['']*len(UIModel.sprds_of_interest)
        self.vm_sprds_running_dv01 = [0.0] * len(UIModel.sprds_of_interest)

        # just a list of large trades that need to be reported topline.
        self.l_bigboys = deque()
        self.vm_bigboys = list()

        # just a list of (eventId, classifyId) tuples,
        # the position in the list is the key for the data table..
        self.l_evts = deque()
        # classifyId -> XDREvent
        self.d_evts = dict()

        # for the ui
        self.latest_events = list()

        # handle with care this is the textual app instance.
        self.app = app_handle

        self.settings_model = None
        self.big_boy_limit = 20
        self.show_utc = True

        self.event_filters = [''] * len(UIModel.XDRPKG_TABLE_COLUMNS)
        self.filter_chain = [None] * len(UIModel.XDRPKG_TABLE_COLUMNS)
        #view nodels

    def add_settings_model(self, settings_model):
        self.settings_model = settings_model

    def load_latest_settings(self):
        self.big_boy_limit = self.settings_model.get_big_boy_limit()
        self.show_utc = self.settings_model.time_display_is_utc()

    def get_top_n_bigboys(self, n):
        # snap the relevant events and keep a copy here
        self.vm_bigboys.clear()
        levts = []
        count = 0
        for classifyId in self.l_bigboys:
            evt = self.d_evts[classifyId]
            if evt.legs == 0:
                continue
            levts.append(evt)
            self.vm_bigboys.append(evt.classifyId)
            count += 1
            if count >= n:
                break
        return levts

    def get_sprd_at_loc(self, iloc):
        # snap the relevant events and keep a copy here
        mne = UIModel.sprds_of_interest[iloc]
        if mne not in self.d_sprds:
            return None
        dq = self.d_sprds[mne]
        if len(dq) == 0:
            return None
        classifyId = dq[0]
        return self.d_evts[classifyId]

    def get_fly_at_loc(self, iloc):
        # snap the relevant events and keep a copy here
        mne = UIModel.flys_of_interest[iloc]
        if mne not in self.d_flys:
            return None
        dq = self.d_flys[mne]
        if len(dq) == 0:
            return None
        classifyId = dq[0]
        return self.d_evts[classifyId]

    def get_crv_at_loc(self, iloc):
        # snap the relevant events and keep a copy here
        mne = UIModel.crvs_of_interest[iloc]
        if mne not in self.d_crvs:
            return None
        dq = self.d_crvs[mne]
        if len(dq) == 0:
            return None
        classifyId = dq[0]
        return self.d_evts[classifyId]

    XDRPKG_TABLE_COLUMNS = ("sef", "type", "description", "legs", "lvl", "dv01", "time")

    def get_table_data(self, classifyId):
        if classifyId not in self.d_evts:
            return None
        evt = self.d_evts[classifyId]
        if evt.legs == 0:
            return None
        hhmmss = evt.get_hhmmss_time(self.show_utc)
        desc = f"{evt.description[1:35]}>>>" if len(evt.description) > 37 else evt.description
        return evt.sef, evt.type, desc, evt.legs, evt.get_formatted_lvl(), f"{evt.dv01}k", hhmmss

    def setup_event_filter(self, col_index, filter_str):
        # prep filter
        col_name = UIModel.XDRPKG_TABLE_COLUMNS[col_index]
        current_filter = self.filter_chain[col_index]
        new_filter = EventFilter(col_name, filter_str, self.show_utc)
        if current_filter is None:
            self.filter_chain[col_index] = new_filter
            return col_index
        elif current_filter != new_filter:
            self.filter_chain[col_index] = new_filter
            return col_index
        return None

    def process_event_filter(self):
        l_classifyIds = []
        for classifyId in self.l_evts:
            evt = self.d_evts[classifyId]
            if self.apply_filter_chain(evt):
                l_classifyIds.append(evt.classifyId)
        return l_classifyIds

    def apply_filter_chain(self, evt: XDREvent):
        for fltr in self.filter_chain:
            if fltr is None or fltr.is_nop():
                continue
            if fltr.apply(evt) is False:
                return False
        return True

    def get_filter_col_style(self, col_index):
        fltr = self.filter_chain[col_index]
        if fltr is None or fltr.is_nop():
            return ""
        return "italic #03AC13"

    # some events have been pre-classified - return true if they have been handled....
    def process_monikered(self, evt):
        if evt.moniker is None:
            return False

        classifyId = evt.classifyId
        # under certain circumstances you could have processed and displayed just a partial trade
        # for example 5y of a 5y vs 10y spread switch. you get the 5y leg first and display it.
        # you get the 10y leg later - so you need to clear what you have already displayed (in this case
        # the outright 5y spread) and replace it with the spread switch (5y vs 10y).
        # slightly non-trivial.
        old_dv01 = 0.0
        old_evt = self.d_evts[classifyId] if classifyId in self.d_evts else None
        if old_evt is not None:
            if PackageType.SPREAD == old_evt.type or PackageType.SPREAD_SWITCH == old_evt.type or PackageType.SPREAD_FLY == old_evt.type:
                if old_evt.moniker in UIModel.sprds_of_interest:
                    old_dq = self.d_sprds[old_evt.moniker]
                    if classifyId in old_dq:
                        old_dq.remove(classifyId)
                        old_iloc = UIModel.sprds_of_interest.index(old_evt.moniker)
                        self.vm_sprds_running_dv01[old_iloc] -= float(old_evt.dv01)
                        self.vm_sprds[old_iloc] = old_dq[0] if len(old_dq) > 0 else None

            elif PackageType.FLY == old_evt.type:
                if old_evt.moniker in UIModel.flys_of_interest:
                    old_dq = self.d_flys[old_evt.moniker]
                    if classifyId in old_dq:
                        old_dq.remove(classifyId)
                        old_iloc = UIModel.flys_of_interest.index(old_evt.moniker)
                        self.vm_flys_running_dv01[old_iloc] -= float(old_evt.dv01)
                        self.vm_flys[old_iloc] = old_dq[0] if len(old_dq) > 0 else None

            elif PackageType.CURVE == old_evt.type:
                if old_evt.moniker in UIModel.crvs_of_interest:
                    old_dq = self.d_crvs[old_evt.moniker]
                    if classifyId in old_dq:
                        old_dq.remove(classifyId)
                        old_iloc = UIModel.crvs_of_interest.index(old_evt.moniker)
                        self.vm_crvs_running_dv01[old_iloc] -= float(old_evt.dv01)
                        self.vm_crvs[old_iloc] = old_dq[0] if len(old_dq) > 0 else None

        if PackageType.SPREAD == evt.type or PackageType.SPREAD_SWITCH == evt.type or PackageType.SPREAD_FLY == evt.type:
            if evt.moniker not in UIModel.sprds_of_interest:
                return False
            if evt.moniker not in self.d_sprds:
                self.d_sprds[evt.moniker] = deque()
            if evt.legs == 0:
                return True

            self.d_sprds[evt.moniker].appendleft(classifyId)
            iloc = UIModel.sprds_of_interest.index(evt.moniker)
            self.vm_sprds_running_dv01[iloc] += float(evt.dv01)
            self.vm_sprds[iloc] = classifyId
            return True

        elif PackageType.FLY == evt.type:
            if evt.moniker not in UIModel.flys_of_interest:
                return False
            if evt.moniker not in self.d_flys:
                self.d_flys[evt.moniker] = deque()
            if evt.legs == 0:
                return True

            self.d_flys[evt.moniker].appendleft(classifyId)
            iloc = UIModel.flys_of_interest.index(evt.moniker)
            self.vm_flys_running_dv01[iloc] += float(evt.dv01)
            self.vm_flys[iloc] = classifyId
            return True

        elif PackageType.CURVE == evt.type:
            if evt.moniker not in UIModel.crvs_of_interest:
                return False
            if evt.moniker not in self.d_crvs:
                self.d_crvs[evt.moniker] = deque()
            if evt.legs == 0:
                return True

            self.d_crvs[evt.moniker].appendleft(classifyId)
            iloc = UIModel.crvs_of_interest.index(evt.moniker)
            self.vm_crvs_running_dv01[iloc] += float(evt.dv01)
            self.vm_crvs[iloc] = classifyId
            return True

        return False

    def process_bigboys(self, evt):
        classifyId = evt.classifyId

        ignore_pkgs = [PackageType.SPREAD, PackageType.SPREAD_FLY, PackageType.SPREAD_SWITCH, PackageType.FLY, PackageType.CURVE, PackageType.INVOICE, PackageType.MMS]
        if evt.type in ignore_pkgs:
            return False

        if classifyId in self.l_bigboys:
            return False

        if abs(evt.dv01) < self.big_boy_limit:
            return False

        self.play_big_boy_jingle()
        self.l_bigboys.appendleft(classifyId)
        return True

    def get_bigboy_at(self, i):
        return self.l_bigboys[i]

    def get_deets_via_db(self, eventId, classifyId):
        sqlDeetsSql = "select * from DEETS where eventId = ? and classifyId = ? ORDER BY end_date"
        cols = list()

        l_deets = list()
        try:
            cursor = self.sql3con.cursor()

            print(f"Running query {sqlDeetsSql} for eventId = {eventId} and classifyId = {classifyId}")
            res = cursor.execute(sqlDeetsSql, (eventId, classifyId,))
            if len(cols) == 0:
                cols = [desc[0] for desc in cursor.description]

            while True:
                r = res.fetchone()
                if r is None:
                    break
                d_deets = {c: v for c, v in zip(cols, r)}
                deets = Deets(d_deets)
                l_deets.append(deets)

        except sqlite3.OperationalError as exp:
            print(f"Error executing query {sqlDeetsSql} against {self.sqlite_file}.")
            print(traceback.print_exc())
            print("-"*80)
            return None
        else:
            cursor.close()

        return l_deets

    def get_deets_via_http(self, eventId, classifyId):
        httpSession = requests.Session()
        xdr_server_deets_url = f'http://{self.server_hostname}/deets'

        url_params = {'eventId': eventId, 'classifyId':classifyId}
        print(f"Running http query against {xdr_server_deets_url} with params {url_params}")

        resp = fire_http_request(httpSession, xdr_server_deets_url, url_params)
        l_result = json.loads(resp.json())
        return [Deets(d_deets) for d_deets in l_result]

    def get_deets(self, classifyId):
        evt = self.d_evts[classifyId]
        if self.server_hostname is None:
            l_deets = self.get_deets_via_db(evt.eventId, classifyId)
        else:
            l_deets = self.get_deets_via_http(evt.eventId, classifyId)

        deets_info = list()
        deets_info.append(f"#sef: **{evt.sef}**        {evt.get_hhmmss_time(self.show_utc)}")
        deets_info.append(f"#executed at : [b]{evt.get_deets_formatted_lvl()}[/]")
        if evt.direction_hint is not None:
            deets_info.append(f"#direction  [i]{Direction.as_str(evt.direction_hint)}[/]")
        deets_info.append("-" * 50)

        for i, tx in enumerate(l_deets):
            deets_info.append("")
            if len(l_deets) > 1:
                deets_info.append(f"leg: {i+1}")
            deets_info.append(f"{tx.get_formatted_notnl()} / (dv01={abs(tx.dv01)}k)")
            deets_info.append(f"[b]{tx.get_formatted_start_date():>12}[/] x [b]{tx.get_formatted_end_date():<12}[/]")
            deets_info.append(f"[b]{tx.start_snap:>12}[/] x [b]{tx.tenor_snap:<12}[/]")
            lvl_block = list()
            lvl_block.append(f"[b]{tx.get_formatted_rate()}%[/]")
            if tx.sprd != 0:
                lvl_block.append(f"[i]margin[/] = [b]{tx.get_formatted_sprd()}bps[/]")
            if tx.upfront != 0:
                lvl_block.append(f"[i]upfront[/] = [b]${tx.get_formatted_upfront()}[/]")
            deets_info.append(" ".join(lvl_block))

            deets_info.append("")
            deets_info.append("-"*50)

        return "\n".join(deets_info)

    def handle(self, d_evt):
        evt = XDREvent(d_evt)
        classifyId = evt.classifyId

        self.process_monikered(evt)
        self.process_bigboys(evt)

        self.d_evts[classifyId] = evt

        already_existed = False
        if classifyId in self.l_evts:
            already_existed = True
            self.l_evts.remove(classifyId)
        self.l_evts.append(classifyId)

        self.latest_events.append((classifyId, already_existed))

        return evt.eventId

    def play_big_boy_jingle(self):
        self.app.call_from_thread(self.app.play_wav)

    def update_ui(self):
        self.app.call_from_thread(self.app.update_events, self.latest_events)
        self.latest_events.clear()

    def listen_to_xdr_events(self):
        if self.server_hostname is None:
            return self.listen_to_xdr_events_via_db()
        else:
            return self.listen_to_xdr_events_via_http()

    def listen_to_xdr_events_via_db(self):
        eventId = 0
        sqlXDREvtSql = """select * from XDREVT where eventId > ? and eventId <= ?"""
        sqlAllXDREvtSql = """select * from XDREVT where eventId > ?"""

        # 2 phase listener,
        # phase #1 read everything until now, phase #2 move incrementally until done....
        cols = list()
        try:
            with sqlite3.connect(self.sqlite_file) as sql3con:
                cursor = sql3con.cursor()

                print(f"Running query {sqlAllXDREvtSql} => sqlite {self.sqlite_file} in phase #1..")
                while True:

                    self.load_latest_settings()

                    res = cursor.execute(sqlAllXDREvtSql, (eventId,))
                    if len(cols) == 0:
                        cols = [desc[0] for desc in cursor.description]

                    while True:
                        r = res.fetchone()
                        if r is None:
                            break
                        d_evt = {c: v for c, v in zip(cols, r)}
                        eventId = self.handle(d_evt)

                    if len(self.latest_events) > 0:
                        self.update_ui()
                    time.sleep(15)
                    break

                i = 1
                while True:
                    self.load_latest_settings()

                    print(f"Running query {sqlXDREvtSql} => sqlite {self.sqlite_file} in phase #2..")
                    res = cursor.execute(sqlXDREvtSql, (eventId, eventId+20*i))
                    if len(cols) == 0:
                        cols = [desc[0] for desc in cursor.description]

                    while True:
                        r = res.fetchone()
                        if r is None:
                            break
                        d_evt = {c: v for c, v in zip(cols, r)}
                        eventId = self.handle(d_evt)

                    if len(self.latest_events) > 0:
                        self.update_ui()
                        i = 1
                    else:
                        i += 1

                    if textual.worker.get_current_worker().is_cancelled:
                        print("xdr event poller ...see ya")
                        return

                    time.sleep(15)

                    if textual.worker.get_current_worker().is_cancelled:
                        print("xdr event poller ...see ya")
                        return

        except sqlite3.OperationalError as exp:
            print(f"Error executing query {sqlXDREvtSql} against {self.sqlite_file}.")
            print(traceback.print_exc())
            print("-"*80)
            #pdb.set_trace()
        except asyncio.CancelledError as exp:
            print(f"Cancel culture. bye bye~")
            #pdb.set_trace()
        except Exception as exp:
            print(f"Oops! bye bye~ message={exp}")
        finally:
            #pdb.set_trace()
            return

    def listen_to_xdr_events_via_http(self):
        eventId = 0

        httpSession = requests.Session()
        xdr_server_events_url = f'http://{self.server_hostname}/events'

        self.load_latest_settings()

        # 2 phase listener,
        # phase #1 read everything until now, phase #2 move incrementally until done....
        while True:
            url_params = {'start': 1}
            print(f"Running http query against {xdr_server_events_url} with params {url_params} in phase #1..")
            resp = fire_http_request(httpSession, xdr_server_events_url, url_params)
            l_events = json.loads(resp.json())

            if l_events is None or len(l_events) <= 0:
                break

            for d_evt in l_events:
                eventId = self.handle(d_evt)

            if len(self.latest_events) > 0:
                self.update_ui()
            time.sleep(15)
            break

        i = 1
        while True:
            self.load_latest_settings()

            url_params = {'start': eventId, 'end': eventId+20*i}
            print(f"Running http query against {xdr_server_events_url} with params {url_params} in phase #2..")
            resp = fire_http_request(httpSession, xdr_server_events_url, url_params)
            l_events = json.loads(resp.json())

            if l_events is not None:
                for d_evt in l_events:
                    eventId = self.handle(d_evt)

            if len(self.latest_events) > 0:
                self.update_ui()
                i = 1
            else:
                i += 1

            if textual.worker.get_current_worker().is_cancelled:
                print("xdr event poller ...see ya")
                return

            time.sleep(15)

            if textual.worker.get_current_worker().is_cancelled:
                print("xdr event poller ...see ya")
                return

    def run_query(self, where_clause):
        sqlSearchQuery = f"select classifyId from XDREVT A {where_clause} " \
                         f"and A.eventId = (select max(eventId) from XDREVT B where B.classifyId = A.classifyId)"

        if self.server_hostname is None:
            return self.run_query_via_db(sqlSearchQuery)
        else:
            return self.run_query_via_http(sqlSearchQuery)

    def run_query_via_db(self, sqlSearchQuery):
        cols = list()
        # the protocol is if error return None else return an empty list if there are no results...
        l_classifyIds = list()
        try:
            cursor = self.sql3con.cursor()

            print(f"Running query{sqlSearchQuery} => sqlite {self.sqlite_file}")
            res = cursor.execute(sqlSearchQuery)
            while True:
                r = res.fetchone()
                if r is None:
                    cursor.close()
                    return l_classifyIds
                l_classifyIds.append(r[0])

        except sqlite3.OperationalError as exp:
            print(f"Error executing query {sqlSearchQuery} against {self.sqlite_file}.")
            print(traceback.print_exc())
            print("-"*80)
            return None

    def run_query_via_http(self, sqlSearchQuery):
        httpSession = requests.Session()
        xdr_server_query_url = f'http://{self.server_hostname}/query'

        url_params = {'qry': sqlSearchQuery}
        print(f"Running http query against {xdr_server_query_url} with params {url_params}.")

        resp = fire_http_request(httpSession, xdr_server_query_url, url_params)
        l_result = json.loads(resp.json())
        return l_result


class SearchModel:
    sqlDefaultWhereClause = "where dv01 > 100;"

    def __init__(self, app_handle, search_query_config_file_path):
        # handle with care this is the textual app instance.
        self.app = app_handle
        self.sqc = SearchQueryConfig(search_query_config_file_path)
        # clauses is a list of sql clauses....
        self.clauses = self.sqc.load()
        if self.clauses is None or self.clauses == 0:
            self.clauses = list()
            self.clauses.append(SearchModel.sqlDefaultWhereClause)
        self.clause_at = 0

    def get_display_label(self):
        return f"{self.clause_at+1} / {len(self.clauses)}"

    def get_active_where_clause(self):
        return self.clauses[self.clause_at]

    def next(self):
        self.clause_at += 1
        l = len(self.clauses)
        if self.clause_at >= l:
            self.clause_at = l-1
        return self.clauses[self.clause_at]

    def prev(self):
        self.clause_at -= 1
        if self.clause_at <= 0:
            self.clause_at = 0
        return self.clauses[self.clause_at]

    def add_clause(self, sql_where_clause):
        if self.clause_at == len(self.clauses) - 1:
            self.clauses.append(SearchModel.sqlDefaultWhereClause)
        self.clauses[self.clause_at] = sql_where_clause
        self.sqc.write(self.clauses)


class SettingsModel:

    BIG_BOY_LIMIT_DEFAULT = 20

    def __init__(self, app_handle, settings_file_path):
        # handle with care this is the textual app instance.
        self.app = app_handle
        self.setc = SettingsConfig(settings_file_path)
        # clauses is a list of sql clauses....
        self.ds = self.setc.load()
        if self.ds is None or not self.ds:
            self.ds = {
                'time_display': "local",
                'big_boy_limit': SettingsModel.BIG_BOY_LIMIT_DEFAULT,
            }

        self.wav_file_location = get_wav_location(settings_file_path)

    def set_time_display(self, is_utc):
        if is_utc is True:
            self.ds['time_display'] = "utc"
        else:
            self.ds['time_display'] = "local"

    def time_display_is_utc(self):
        return self.ds['time_display'] == "utc"

    def set_big_boy_limit(self, limit):
        try:
            limit_size = int(limit.strip())
            self.ds['big_boy_limit'] = limit_size
        except ValueError as ve:
            return

    def get_big_boy_limit(self):
        return self.ds['big_boy_limit']

    def get_wav_file(self):
        return f"{self.wav_file_location}\\bigboy.wav"

    def save(self):
        self.setc.write(self.ds)
