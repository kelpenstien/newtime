from events import XDREvent
from datetime import datetime
from dateutil import tz

utc_zone = tz.tzutc()
local_zone = tz.tzlocal()


class EventFilter:
    OPS = ['=', '!=', '>', '<', '>=', '<=', '~']

    asofdate = datetime.today()
    @classmethod
    def set_as_of_date(cls, aod):
        cls.asofdate = aod

    @staticmethod
    def infer_predicate(v, show_utc):
        ok, predicate = EventFilter.try_int(v)
        if ok is False:
            ok, predicate = EventFilter.try_float(v)
        if ok is False:
            ok, predicate = EventFilter.try_datetime(v, show_utc)
        if ok is False:
            predicate = v
        return predicate

    def __init__(self, target, sfilter, show_utc):
        f = sfilter.strip()
        first_char = f[:1]
        first2_chars = f[:2]
        index = -1
        if first2_chars in EventFilter.OPS:
            index = EventFilter.OPS.index(first2_chars)
            v = f[2:].strip()
            self.predicate = EventFilter.infer_predicate(v, show_utc)
        elif first_char in EventFilter.OPS:
            index = EventFilter.OPS.index(first_char)
            v = f[1:].strip()
            self.predicate = EventFilter.infer_predicate(v, show_utc)
        else:
            # noop
            self.op = None
            self.predicate = None
            return

        self.op = EventFilter.OPS[index]
        self.tgt = target
        self.clause = f

    def __eq__(self, o):
        if o.op == self.op and o.predicate == self.predicate:
            return True
        return False

    def __ne__(self, o):
        return not o.__eq__(self)

    @classmethod
    def try_int(cls, x):
        try:
            return True, int(x)
        except ValueError as ve:
            return False, None

    @classmethod
    def try_float(cls, x):
        try:
            return True, float(x)
        except ValueError as ve:
            return False, None

    @classmethod
    def try_datetime(cls, x, is_utc):
        try:
            if is_utc:
                return True, datetime.combine(cls.asofdate, datetime.strptime(x, "%H:%M:%S").time()).replace(tzinfo=utc_zone)
            else:
                lt = datetime.combine(cls.asofdate, datetime.strptime(x, "%H:%M:%S").time()).replace(tzinfo=local_zone)
                return True, lt.astimezone(utc_zone)
        except ValueError as ve:
            return False, None

    def is_nop(self):
        return self.op is None

    def apply(self, evt: XDREvent):
        val, t = evt.resolve_target(self.tgt)

        if self.op is None:
            return

        if t == str:
            if self.op == '=':
                return val == self.predicate
            elif self.op == '!=':
                return val != self.predicate
            elif self.op == '>':
                return val > self.predicate
            elif self.op == '<':
                return val < self.predicate
            elif self.op == '>=':
                return val >= self.predicate
            elif self.op == '=>':
                return val <= self.predicate
            elif self.op == '~':
                return True if val.find(self.predicate) > -1 else False

        elif t == int:
            if self.op == '=':
                return val == self.predicate
            elif self.op == '!=':
                return val != self.predicate
            elif self.op == '>':
                return val > self.predicate
            elif self.op == '<':
                return val < self.predicate
            elif self.op == '>=':
                return val >= self.predicate
            elif self.op == '=>':
                return val <= self.predicate
            elif self.op == '~':
                return True if abs(val - self.predicate) < 2 else False

        elif t == float:
            if self.op == '=':
                return abs(val - self.predicate) < 0.0001
            elif self.op == '!=':
                return val != self.predicate
            elif self.op == '>':
                return val > self.predicate
            elif self.op == '<':
                return val < self.predicate
            elif self.op == '>=':
                return val >= self.predicate
            elif self.op == '=>':
                return val <= self.predicate
            elif self.op == '~':
                return True if abs(val - self.predicate) < 0.02 else False

        elif t == datetime:
            if self.op == '=':
                return val == self.predicate
            elif self.op == '!=':
                return val != self.predicate
            elif self.op == '>':
                return val > self.predicate
            elif self.op == '<':
                return val < self.predicate
            elif self.op == '>=':
                return val >= self.predicate
            elif self.op == '=>':
                return val <= self.predicate
            elif self.op == '~':
                return True if (val - self.predicate).seconds < 120 else False
