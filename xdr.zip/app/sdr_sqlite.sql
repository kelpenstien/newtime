DROP TABLE if EXISTS XDREVT;
 
CREATE TABLE XDREVT (
eventId INTEGER not null,
classifyId TEXT not null,
ts TEXT not null,
sef TEXT not null,
type TEXT not null,
description TEXT not null,
moniker TEXT null,
legs INTEGER not null,
lvl REAL not null,
lvl_type INTEGER not null,
dv01 INTEGER not null,
direction_hint TEXT null
);

CREATE UNIQUE INDEX if not EXISTS XDR_EVENT_CLASSIFY_ID_IDX on XDREVT(eventId, classifyId);
 
DROP TABLE if EXISTS DEETS;
 
CREATE TABLE DEETS (
eventId INTEGER not null,
classifyId TEXT not null,
oid TEXT not null,
notnl INTEGER not null,
start_date TEXT not null,
end_date TEXT not null,
start_snap TEXT not null,
end_snap TEXT not null,
tenor_snap TEXT not null,
rate REAL null,
spread REAL null,
upfront REAL null,
lvl TEXT not null,
lvl_type INTEGER not null,
dv01 INTEGER not null
);

CREATE INDEX if not EXISTS DEETS_CLASSIFYID_IDX on DEETS(classifyId);
CREATE INDEX if not EXISTS DEETS_EVENT_CLASSIFY_ID_IDX on DEETS(eventId, classifyId);
