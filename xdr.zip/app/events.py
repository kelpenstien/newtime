from datetime import datetime
from xdrtypes import LevelType, PackageType, Direction
from dateutil import tz

utc_zone = tz.tzutc()
local_zone = tz.tzlocal()


class XDREvent:
    def __init__(self, d_evt):
        self.eventId = d_evt['eventId']
        self.classifyId = d_evt['classifyId']
        self.ts = datetime.fromisoformat(d_evt['ts']).replace(tzinfo=utc_zone)
        self.sef = d_evt['sef']
        self.type = PackageType(d_evt['type'])
        self.description = d_evt['description']
        self.moniker = d_evt['moniker']
        self.legs = d_evt['legs']
        self.lvl = d_evt['lvl']
        self.lvl_type = LevelType(d_evt['lvl_type'])
        self.dv01 = abs(d_evt['dv01'])
        direction_hint = d_evt['direction_hint']
        self.direction_hint = Direction('' if direction_hint is None else direction_hint)

    def get_elapsed_time(self, now):
        return int((now - self.ts).seconds/60)

    def get_hhmmss_time(self, is_utc):
        if is_utc:
            return self.ts.strftime('%H:%M:%S')
        else:
            return self.ts.astimezone(local_zone).strftime('%H:%M:%S')

    def get_formatted_direction_hint(self):
        return Direction.as_str(self.direction_hint), Direction.color_code(self.direction_hint)

    def get_formatted_lvl(self):
        if abs(10 - self.lvl) < 0.0000001:
            return '10'
        ldf = '%.5f'
        if self.lvl_type == LevelType.PRICE:
            return f'${self.lvl:,.0f}'
        elif self.type == PackageType.FLY or self.type == PackageType.CURVE:
            return '%.5g' % self.lvl
        elif self.type == PackageType.SPREAD or self.type == PackageType.SPREAD_FLY or self.type == PackageType.SPREAD_SWITCH:
            return '%.4g' % self.lvl
        elif self.type == PackageType.MULTI_LEG or self.type == PackageType.OUTRIGHT:
            if abs(self.lvl) > 100:
                return f'${self.lvl:,}'
            else:
                return '%.4g' % self.lvl
        return ldf % self.lvl

    def get_deets_formatted_lvl(self):
        if abs(10 - self.lvl) < 0.0000001:
            return '10'
        ldf = '%.5f'
        if self.lvl_type == LevelType.PRICE:
            return f'${self.lvl:,.0f}'
        elif self.type == PackageType.FLY or self.type == PackageType.CURVE:
            return '%.5g' % self.lvl
        elif self.type == PackageType.SPREAD or self.type == PackageType.SPREAD_FLY or self.type == PackageType.SPREAD_SWITCH:
            return '%.5g' % self.lvl
        elif self.type == PackageType.MULTI_LEG or self.type == PackageType.OUTRIGHT:
            if abs(self.lvl) > 100:
                return f'${self.lvl:,}'
            else:
                return '%.5g' % self.lvl
        return ldf % self.lvl


    def resolve_target(self, tgt):
        if tgt == "sef":
            return self.sef, str
        elif tgt == "type":
            return self.type, str
        elif tgt == "description":
            return self.description, str
        elif tgt == "lvl":
            return self.lvl, float
        elif tgt == "legs":
            return self.legs, int
        elif tgt == "dv01":
            return self.dv01, float
        elif tgt == "time":
            return self.ts, datetime


class Deets:
    def __init__(self, d_deets):
        self.eventId = d_deets['eventId']
        self.classifyId = d_deets['classifyId']
        self.oid = d_deets['oid']
        self.notnl = d_deets['notnl']
        self.start_date = datetime.fromisoformat(d_deets['start_date']).date()
        self.end_date = datetime.fromisoformat(d_deets['end_date']).date()
        self.start_snap = d_deets['start_snap']
        self.end_snap = d_deets['end_snap']
        self.tenor_snap = d_deets['tenor_snap']
        self.rate = d_deets['rate']
        self.sprd = d_deets['spread']
        self.upfront = d_deets['upfront']
        self.lvl = d_deets['lvl']
        self.lvl_type = LevelType(d_deets['lvl_type'])
        self.dv01 = abs(d_deets['dv01'])

    def get_formatted_lvl(self):
        if abs(10 - self.lvl) < 0.0000001:
            return '10'
        ldf = '%.5f'
        if self.lvl_type == LevelType.PRICE:
            return f'{self.lvl:,.0f}'
        elif self.lvl_type == LevelType.SPREAD:
            return '%.4f' % self.lvl
        elif self.lvl_type == LevelType.RATE:
            return '%.5g' % self.lvl

        return ldf % self.lvl

    def get_formatted_rate(self):
        return '%.5g' % self.rate

    def get_formatted_sprd(self):
        return '%.4f' % self.sprd

    def get_formatted_upfront(self):
        return f'{self.upfront:,.0f}'

    def get_formatted_notnl(self):
        return f'{self.notnl:,.0f}'

    def get_formatted_start_date(self):
        return self.start_date.strftime("%d%b%y")

    def get_formatted_end_date(self):
        return self.end_date.strftime("%d%b%y")
