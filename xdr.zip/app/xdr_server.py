import datetime
import argparse
import os
import sys
import json
import sqlite3
import asyncio
import traceback
import threading
from concurrent import futures

import uvicorn
from fastapi import FastAPI
from contextlib import asynccontextmanager


def sqlite_init(sqlite_file_path, sqlite_file_name):
    sql_file = f"{sqlite_file_path}{sqlite_file_name}"
    if os.path.isfile(sql_file):
        print(f"{sql_file} already exists...will use this file")
        return sql_file
    else:
        print(f"{sql_file} does not exist...Aborting.")
        return None


class AsyncSQLiteQueryMultiplexer:
    def __init__(self, database_file):
        self.sqlite_file = database_file
        # threadid to sqlite conn dictionary
        self.d_conn = dict()
        self.exec_pool: futures.ThreadPoolExecutor = None
        self.max_workers = 3

    async def __aenter__(self):
        self.exec_pool = futures.ThreadPoolExecutor(max_workers=self.max_workers)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        loop = asyncio.get_running_loop()
        await asyncio.gather(
            *[loop.run_in_executor(self.exec_pool, self.cleanup) for i in range(0, self.max_workers)]
        )

    def cleanup(self):
        sql3con = self.get_thread_specific_sqlite_connection(connect_on_demand=False)
        if sql3con is None:
            return
        try:
            sql3con.close()
        except sqlite3.OperationalError as exp:
            print(f"Error trying to close connection against {self.sqlite_file}.")
            print(traceback.print_exc())
            # pdb.set_trace()
        except asyncio.CancelledError as exp:
            print(f"Cancel culture. bye bye~")
            # pdb.set_trace()
        except Exception as exp:
            return

    def get_thread_specific_sqlite_connection(self, connect_on_demand=True):
        id = threading.get_ident()
        if id in self.d_conn:
            return self.d_conn[id]
        elif connect_on_demand is True:
            return sqlite3.connect(self.sqlite_file)
        return None

    sqlXDREvtSql = """select * from XDREVT where eventId > ? and eventId <= ?"""
    sqlAllXDREvtSql = """select * from XDREVT where eventId > ?"""

    async def query_xdr_events(self, start_eventId, end_eventId):
        qry = AsyncSQLiteQueryMultiplexer.sqlAllXDREvtSql if end_eventId is None else AsyncSQLiteQueryMultiplexer.sqlXDREvtSql
        t_qry_args = (start_eventId,) if end_eventId is None else (start_eventId, end_eventId)
        print(f"Running query {qry} passing in parameters {t_qry_args}")

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(self.exec_pool, self.query_thread, qry, t_qry_args)
        return result

    async def run_query(self, qry):
        print(f"Running query {qry}")
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(self.exec_pool, self.query_thread, qry)
        return result

    sqlDeetsSql = "select * from DEETS where eventId = ? and classifyId = ? ORDER BY end_date"

    async def get_deets(self, eventId, classifyId):
        print(f"Running query {AsyncSQLiteQueryMultiplexer.sqlDeetsSql}")
        t_qry_args = (eventId, classifyId)
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(self.exec_pool, self.query_thread, AsyncSQLiteQueryMultiplexer.sqlDeetsSql, t_qry_args)
        return result

    def query_thread(self, qry, t_qry_args=None):
        sql3con = self.get_thread_specific_sqlite_connection()
        print(f"Try to execute query {qry} with params {t_qry_args} against {self.sqlite_file}.")
        cols = list()
        try:
            cursor = sql3con.cursor()
            if t_qry_args is None:
                res = cursor.execute(qry)
            else:
                res = cursor.execute(qry, t_qry_args)

            if len(cols) == 0:
                cols = [desc[0] for desc in cursor.description]
            return_as_list = True if len(cols) == 1 else False

            ld_results = list()
            while True:
                r = res.fetchone()
                if r is None:
                    break
                if return_as_list is True:
                    ld_results.append(r[0])
                else:
                    d_evt = {c: v for c, v in zip(cols, r)}
                    ld_results.append(d_evt)
            return ld_results
        except sqlite3.OperationalError as exp:
            print(f"Error executing query {qry} with params {t_qry_args} against {self.sqlite_file}.")
            print(traceback.print_exc())
            print("-" * 80)
            # pdb.set_trace()
            return list()
        except asyncio.CancelledError as exp:
            print(f"Cancel culture. bye bye~")
            # pdb.set_trace()
            return list()
        except Exception as exp:
            print(f"Oops! bye bye~ message={exp}")
            return list()


@asynccontextmanager
async def lifespan(app: FastAPI):
    today = datetime.datetime.today()

    arghandler = argparse.ArgumentParser(prog='xdr_server.py',
                                         description='Serve the xdr database to all listening clients...')
    arghandler.add_argument('-r', '--remote_data_path', default='y:\\AM\\NYC\\Rates\\Traders\\Swaps\\sheldon\\dtcc\\')
    # start and end dates are inclusive >=start date and <= end date
    arghandler.add_argument('-t', '--asofdate', default=today, type=datetime.date.fromisoformat)
    argx = arghandler.parse_args()

    asofdate = argx.asofdate
    dt_yyyy_mm_dd = asofdate.strftime("%Y_%m_%d")
    yyyy_mm_dd = asofdate.strftime("%Y-%m-%d")

    # where the processed data is saved and is shared between listeners on the network (good luck)
    remote_data_file_path = argx.remote_data_path
    remote_sqlite_file_name = f"{dt_yyyy_mm_dd}.db"
    remote_sqlite_file = sqlite_init(remote_data_file_path, remote_sqlite_file_name)
    if remote_sqlite_file is None:
        sys.exit(0)

    # stuff here get executed at start up
    async with AsyncSQLiteQueryMultiplexer(remote_sqlite_file) as sqlite_mux:
        app.state.sqlite_mux = sqlite_mux
        yield
        # stuff after yield get executed at shutdown

app = FastAPI(lifespan=lifespan)


@app.get("/events")
async def get_events(start: int, end: int | None = None):
    sqlmux = app.state.sqlite_mux
    result = await sqlmux.query_xdr_events(start, end)
    return json.dumps(result)

@app.get("/query")
async def run_query(qry: str):
    sqlmux = app.state.sqlite_mux
    result = await sqlmux.run_query(qry)
    return json.dumps(result)

@app.get("/deets")
async def get_deets(eventId: int, classifyId: str):
    sqlmux = app.state.sqlite_mux
    result = await sqlmux.get_deets(eventId, classifyId)
    return json.dumps(result)


if __name__ == '__main__':
    # long story
    # i want to run this so that it can serve other PCs (not just local host)
    # to do this i need one thing
    # - has to run via fingals python install viz C:\Program Files\Nomura\Fingal64\Python\Python311 (orochi hack)
    # but alas fingal ships with empty websockets module which confuses the hell out of uvicorn which
    # it tries to load support for websockets, so i stub it out here by setting it to none.
    uvicorn.run("xdr_server:app", host="0.0.0.0", port=5005, reload=False, ws=None)
