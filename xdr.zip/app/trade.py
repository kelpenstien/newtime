import datetime
import sortedcontainers

from xdrtypes import LevelType
from mkt_static import ust, ctd, fomc

from finglib.bind import fpx
import finglib.date as fdate


class Trade:
    id = None
    oid = None
    spot = None
    mkt = None
    ust = None
    ctd = None
    fomc = None
    sl_grid = sortedcontainers.SortedList()
    l_grid_mne = []
    sl_grid_imm = sortedcontainers.SortedList()
    l_grid_mne_imm = []
    sl_grid_all = sortedcontainers.SortedList()
    l_grid_mne_all = []
    l_dv01s = []

    non_imm_grid = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "10m", "11m",
                    "1y", "1y3m", "18m", "1y9m",
                    "2y", "2y3m", "2y6m", "2y9m",
                    "3y", "3y3m", "3y6m", "3y9m",
                    "4y", "4y3m", "4y6m", "4y9m",
                    "5y", "5y3m", "5y6m", "5y9m",
                    "6y", "6y3m", "6y6m", "6y9m",
                    "7y", "7y3m", "7y6m", "7y9m",
                    "8y", "8y3m", "8y6m", "8y9m",
                    "9y", "9y3m", "9y6m", "9y9m",
                    "10y", "10y6m",
                    "11y", "11y6m",
                    "12y", "12y6m",
                    "13y", "13y6m",
                    "14y", "14y6m",
                    "15y", "15y6m",
                    "16y", "17y", "18y", "19y",
                    "20y", "20y6m",
                    "21y", "22y", "23y", "24y",
                    "25y", "25y6m",
                    "26y", "27y", "28y", "29y",
                    "30y", "31y", "32y", "33y", "34y", "35y", "35y6m",
                    "36y", "37y", "38y", "39y",
                    "40y", "40y6m", "41y",
                    "45y", "45y6m", "46y",
                    "50y", "50y6m", "51y",
                    "60y", "60y6m", "61y",
                    "70y"]

    @staticmethod
    def stripper(s):
        if type(s) == str:
            return s.replace(',', '').replace('+', '')
        return s

    @staticmethod
    def floater(f):
        try:
            if type(f) == str:
                f = f.replace(',', '')
            return float(f)
        except ValueError as e:
            return 0.0

    def fxd_rate_matches(self, other_trades):
        if len(other_trades) == 0:
            return True
        for ot in other_trades:
            if self.fxd_rate_leg != ot.fxd_rate_leg:
                return False
        return True

    def sprd_matches(self, other_trades):
        if len(other_trades) == 0:
            return True
        for ot in other_trades:
            if self.sprd_leg != ot.sprd_leg:
                return False
        return True

    @classmethod
    def make(cls, d_trd):
        t = Trade()
        trd = d_trd

        t.id = trd['DISSEMINATION_IDENTIFIER']
        t.oid = trd['ORIGINAL_DISSEMINATION_IDENTIFIER']
        if t.oid == "":
            t.oid = t.id

        t.evtDt = datetime.datetime.fromisoformat(trd['EXECUTION_TIMESTAMP'])

        # i don't really use the flag - prefer to tread every update as a full update...
        t.isAmend = True if trd['AMENDMENT_INDICATOR'] == "true" else False
        if t.isAmend is False:
            action_type = trd['ACTION_TYPE']
            t.isAmend = True if action_type == "MODI" or action_type == "CORR" else False

        # seems to suggest Amends have priority over Cancels, spec is not clear but
        # they are perhaps orthogonal.
        if t.isAmend is False:
            action_type = trd['ACTION_TYPE']
            t.isCancel = True if action_type == "EROR" else False

        t.startDt = datetime.datetime.fromisoformat(trd['EFFECTIVE_DATE']).date()
        t.i_startDt = fdate.datetime_to_excel(t.startDt)
        t.endDt = datetime.datetime.fromisoformat(trd['EXPIRATION_DATE']).date()
        t.i_endDt = fdate.datetime_to_excel(t.endDt)

        t.platform_id = trd['PLATFORM_IDENTIFIER']
        t.isBlock = True if trd['BLOCK_TRADE_ELECTION_INDICATOR'].upper() == "TRUE" else False

        is_large_notnl_1 = True if type(trd['NOTIONAL_AMOUNT_LEG_1']) == str and trd['NOTIONAL_AMOUNT_LEG_1'][-1] == '+' else False
        t.notnl_leg1 = int(Trade.stripper(trd['NOTIONAL_AMOUNT_LEG_1']))

        is_large_notnl_2 = True if type(trd['NOTIONAL_AMOUNT_LEG_2']) == str and trd['NOTIONAL_AMOUNT_LEG_2'][-1] == '+' else False
        t.notnl_leg2 = int(Trade.stripper(trd['NOTIONAL_AMOUNT_LEG_2']))

        t.notnl = t.notnl_leg1 if t.notnl_leg1 > t.notnl_leg2 else t.notnl_leg2

        t.is_large_notnl = True if is_large_notnl_1 is True or is_large_notnl_2 is True else False

        t.fxd_rate_leg1 = Trade.floater(trd['FIXED_RATE_LEG_1']) * 100
        t.fxd_rate_leg2 = Trade.floater(trd['FIXED_RATE_LEG_2']) * 100
        t.fxd_rate_leg = max(t.fxd_rate_leg1, t.fxd_rate_leg2)

        t.sprd_leg1 = Trade.floater(trd['SPREAD_LEG_1']) * 10000.0
        t.sprd_leg2 = Trade.floater(trd['SPREAD_LEG_2']) * 10000.0
        t.sprd_leg = t.sprd_leg1 if abs(t.sprd_leg1) == (abs(t.sprd_leg1), abs(t.fxd_rate_leg2)) else t.sprd_leg2

        t.seq = trd['SEQ']

        # for example :
        # DAIL = daily
        # WEEK = Weekly
        # MNTH = Monthly
        # YEAR =  Yearly
        # EXPI = End of term

        t.flt_freq_leg1 = trd['FLOATING_RATE_RESET_FREQUENCY_PERIOD_LEG_1']
        t.flt_freq_leg2 = trd['FLOATING_RATE_RESET_FREQUENCY_PERIOD_LEG_2']
        # the actual period corresponding to the period ABOVE
        t.flt_freq_mul_leg1 = trd['FLOATING_RATE_RESET_FREQUENCY_PERIOD_MULTIPLIER_LEG_1']
        t.flt_freq_mul_leg2 = trd['FLOATING_RATE_RESET_FREQUENCY_PERIOD_MULTIPLIER_LEG_1']

        t.other_pymt_amt = Trade.floater(trd['OTHER_PAYMENT_AMOUNT'])
        t.other_pymt_type = trd['OTHER_PAYMENT_TYPE']

        t.pkg_indicator = True if trd['PACKAGE_INDICATOR'] == 'true' else False
        t.pkg_price_notation = trd['PACKAGE_TRANSACTION_PRICE_NOTATION']
        t.pkg_price = Trade.floater(trd['PACKAGE_TRANSACTION_PRICE'])
        t.pkg_sprd_notation = trd['PACKAGE_TRANSACTION_SPREAD_NOTATION']
        t.pkg_sprd = Trade.floater(trd['PACKAGE_TRANSACTION_SPREAD'])

        # this is to account for the case where a spread
        # masquerading as a price
        if t.pkg_price_notation == '3' and 0 < abs(t.pkg_price) < 0.01:
            t.pkg_sprd = t.pkg_price * 10000.0
            t.pkg_price = 0.0
        else:
            if t.pkg_sprd_notation == '3':
                t.pkg_sprd = t.pkg_sprd * 100.0
            if 0 <= abs(t.pkg_sprd) < 1:
                t.pkg_sprd = t.pkg_sprd * 100.0

        t.enrich()
        return t

    @classmethod
    def build_statics(cls, today, mkt_path):
        cls.init_dates_grid(today)
        cls.init_dv01s(today, mkt_path)
        cls.init_bonds(mkt_path)
        cls.init_bond_futures(mkt_path)
        cls.init_fomc(mkt_path)


    @classmethod
    def init_bonds(cls, mkt_path):
        cls.ust = ust.UST.from_file(mkt_path)

    @classmethod
    def init_bond_futures(cls, mkt_path):
        cls.ctd = ctd.BondFutureCTD.from_file(mkt_path)

    @classmethod
    def init_fomc(cls, mkt_path):
        cls.fomc = fomc.FOMC.from_file(mkt_path)


    @classmethod
    def get_idate_for_mne(cls, mne):
        i = cls.l_grid_mne_all.index(mne)
        return cls.sl_grid_all[i]

    @classmethod
    def init_dates_grid(cls, today):
        spot = fpx().NextBizDay(today, 2, "NY")
        cls.spot = spot
        cls.sl_grid.add(spot)
        cls.l_grid_mne.append("spot")
        cls.sl_grid_all.add(spot)
        cls.l_grid_mne_all.append("spot")

        for endDtMnemonic in cls.non_imm_grid:
            endDt = fpx().ParseInterval(endDtMnemonic, spot, None, "UnAdj", "S")
            at = cls.sl_grid.bisect_right(endDt)
            cls.sl_grid.add(endDt)
            cls.l_grid_mne.insert(at, endDtMnemonic)
            at = cls.sl_grid_all.bisect_right(endDt)
            cls.sl_grid_all.add(endDt)
            cls.l_grid_mne_all.insert(at, endDtMnemonic)

        # add imms out to 27.5yrs
        immDt = cls.spot
        month_mnemonic = {3: 'h', 6: 'm', 9: 'u', 12: 'z'}
        for i in range(1, 110):
            immDt = fpx().NextImmDate(immDt, None, None)
            imm_as_pythondate = fdate.date_from_excel(immDt)
            hmuz = month_mnemonic[imm_as_pythondate.month] + str(imm_as_pythondate.year)[2:]
            at = cls.sl_grid_imm.bisect_right(immDt)
            cls.sl_grid_imm.add(immDt)
            cls.l_grid_mne_imm.insert(at, hmuz)
            at = cls.sl_grid_all.bisect_right(immDt)
            cls.sl_grid_all.add(immDt)
            cls.l_grid_mne_all.insert(at, hmuz)
            immDt = immDt + 1

    @classmethod
    def init_dv01s(cls, today, mkt_path):
        print("generating dv01s...")
        cls.mkt = fpx().MktLoad("XDR_", f"{mkt_path}crv.mkt")
        fpx().MktSetDealDate(cls.mkt, today)
        for end_dt in cls.sl_grid_all:
            if cls.spot == end_dt:
                cls.l_dv01s.append(0.0)
                continue

            print(f"{cls.spot} x {end_dt} for 10m = ", end='')
            roll_day = fdate.date_from_excel(end_dt).day
            (_, t_dv01) = fpx().InterestRateSwapWithReceivedFixings(cls.mkt + "USD.KCurve", -10_000_000, "Par", 0,
                                                                    "Act/360", "Act/360", cls.spot, end_dt, "12m",
                                                                    "12m", roll_day, None, None, None, None, None, None,
                                                                    None, None, None, None, None, None, None, "FltPV01",
                                                                    None, None, "USD-SOFR-COMPOUND")
            cls.l_dv01s.append(t_dv01[0])
            print(f"{t_dv01[0]}")

    def __init__(self):
        self.is_pkg = False
        self.lvl_type = False
        self.lvl = None

        self.notnl = 0.0

        self.fxd_rate_leg1 = 0.0
        self.fxd_rate_leg2 = 0.0
        self.fxd_rate_leg = 0.0

        self.sprd_leg1 = 0.0
        self.sprd_leg2 = 0.0
        self.sprd_leg = 0.0

        self.other_pymt_amt = 0.0
        self.other_pymt_type = None

        self.evtDt = None
        self.i_startDt = 0
        self.startDt = None
        self.i_endDt = 0
        self.endDt = None
        self.start_snap = None
        self.end_snap = None
        self.is_spot_start = False
        self.is_start_exact = False
        self.is_end_exact = False
        self.tenor_snap = None
        self.risk = [0.0] * len(Trade.l_dv01s)

        self.classifyId = None

        self.pkg_indicator = False
        self.pkg_sprd = 0.0

        self.bond = None
        self.fomc = None
        self.invoice_fut = None
        self.invoice_setl = None

        # could be a spread leg (updated in enrich)
        self.is_spread_compatible = False
        self.is_crvfly_compatible = False
        self.is_invoice_compatible = False
        self.is_mms_compatible = False
        self.is_fomc_compatible = False

        self.isAmend = False
        self.isCancel = False

        self.platform_id = None

    def is_classified(self):
        return True if self.classifyId is None else False

    def build_classify_id(self):
        hms = self.evtDt.strftime("%H%M%S")
        self.classifyId = f"{self.platform_id}_{self.lvl}_{hms}"
        return self.classifyId

    def inherit_classify_id(self, inherit_from_trd):
        self.classifyId = inherit_from_trd.classifyId
        return self.classifyId

    def check_spread_compatible(self):
        if not self.is_start_exact:
            return False
        if self.start_snap != 'spot':
            return False
        if not self.is_end_exact:
            return False
        if self.end_snap not in ["2y", "3y", "5y", "7y", "10y", "20y", "30y"]:
            return False
        if self.pkg_indicator is False:
            return False
        if self.fxd_rate_leg == 0.0:
            return False
        if self.sprd_leg != 0.0:
            return False
        if self.other_pymt_amt != 0.0:
            return False
        if self.lvl_type != LevelType.SPREAD:
            return False
        if self.lvl == 0.0:
            return False

        return True

    def check_invoice_compatible(self):
        if self.invoice_fut is None:
            return False
        if self.fxd_rate_leg == 0.0:
            return False
        if self.sprd_leg != 0.0:
            return False
        if self.lvl == 0.0:
            return False

        return True

    def check_mms_compatible(self):
        if self.bond is None:
            return False
        #if the end is exact then weve fallen on a tenor, so this is probably just a standard trade.
        if self.is_end_exact:
            return False
        i1m = Trade.get_idate_for_mne("1m")
        if self.i_startDt >= i1m:
            return False
        if self.fxd_rate_leg == 0.0:
            return False
        if self.sprd_leg != 0.0:
            return False
        if self.lvl == 0.0:
            return False

        return True

    def check_fomc_compatible(self):
        if self.fomc is None:
            return False
        if self.fxd_rate_leg == 0.0:
            return False
        if self.sprd_leg != 0.0:
            return False
        if self.lvl_type != LevelType.RATE and self.lvl_type != LevelType.SPREAD:
            return False
        if self.lvl == 0.0:
            return False

        return True

    def check_curve_fly_compatible(self):
        if not self.is_start_exact:
            return False
        if self.pkg_indicator is False:
            return False
        if self.fxd_rate_leg == 0.0:
            return False
        if self.sprd_leg != 0.0:
            return False
        if self.lvl_type == LevelType.RATE:
            return False
        if self.lvl == 0.0:
            return False

        return True

    def enrich(self):
        # when dealing with cancels rather than _disappear_ the trade just set the notional to zero.
        if self.isCancel:
            self.notnl = 0

        (self.start_snap, self.is_start_exact, self.is_start_imm, self.is_bkwd_start) = \
            self.snap_date_to_grid(self.i_startDt)
        (self.end_snap, self.is_end_exact, self.is_end_imm, _) = self.snap_date_to_grid(self.i_endDt)
        (self.tenor_snap, _, _, _) = self.snap_date_to_grid(Trade.spot + (self.i_endDt - self.i_startDt), skip_imm_check = True)

        self.is_spot_start = True if self.i_startDt == Trade.spot else False
        self.calc_dv01()

        if self.pkg_indicator is True and self.pkg_price != 0.0:
            self.lvl_type = LevelType.PRICE
            self.lvl = self.pkg_price
        elif self.pkg_indicator is True and self.pkg_sprd != 0.0:
            self.lvl_type = LevelType.SPREAD
            self.lvl = self.pkg_sprd
        else:
            if self.fxd_rate_leg1 != 0.0:
                self.lvl_type = LevelType.RATE
                self.lvl = self.fxd_rate_leg1
            elif self.fxd_rate_leg2 != 0.0:
                self.lvl_type = LevelType.RATE
                self.lvl = self.fxd_rate_leg2
            elif self.sprd_leg1 != 0.0:
                self.lvl_type = LevelType.SPREAD
                self.lvl = self.sprd_leg1
            elif self.sprd_leg2 != 0.0:
                self.lvl_type = LevelType.SPREAD
                self.lvl = self.sprd_leg2

        self.invoice_fut, self.invoice_setl = Trade.ctd.for_start_end(self.i_startDt, self.i_endDt)
        self.fomc = Trade.fomc.for_start_end(self.i_startDt, self.i_endDt)
        self.bond = Trade.ust.for_maturity(self.i_endDt)

        self.is_spread_compatible = self.check_spread_compatible()
        self.is_crvfly_compatible = self.check_curve_fly_compatible()
        self.is_invoice_compatible = self.check_invoice_compatible()
        self.is_fomc_compatible = self.check_fomc_compatible()
        self.is_mms_compatible = self.check_mms_compatible()

    def imm_grid_snap(self, dt, _what_is_exact_=0):
        # who am i closer to left or right (imm)?
        at = Trade.sl_grid_imm.bisect_right(dt)
        lat = at - 1
        rat = at if at < len(Trade.sl_grid_imm) else at - 1

        ldt = Trade.sl_grid_imm[lat]
        rdt = Trade.sl_grid_imm[rat]
        if abs(dt - ldt) == _what_is_exact_:
            is_exact = True
            is_imm = True
            return Trade.l_grid_mne_imm[lat], is_exact, is_imm
        elif abs(rdt - dt) == _what_is_exact_:
            is_exact = True
            is_imm = True
            return Trade.l_grid_mne_imm[rat], is_exact, is_imm

        return None, False, False

    def standard_grid_snap(self, dt, _what_is_exact_=0):
        # who am i closer to left or right ?
        at = Trade.sl_grid.bisect_right(dt)
        lat = at - 1
        rat = at if at < len(Trade.sl_grid) else at - 1
        ldt = Trade.sl_grid[lat]
        rdt = Trade.sl_grid[rat]
        if dt - ldt <= rdt - dt:
            is_exact = abs(dt - ldt) <= _what_is_exact_
            return Trade.l_grid_mne[lat], is_exact
        else:
            is_exact = abs(rdt - dt) <= _what_is_exact_
            return Trade.l_grid_mne[rat], is_exact



    def snap_date_to_grid(self, dt, skip_imm_check=False):
        is_bkwd_start = False
        is_imm = False

        # backward start
        if dt < Trade.spot:
            is_exact = False
            is_bkwd_start = True
            return Trade.l_grid_mne[0], is_exact, is_imm, is_bkwd_start
        # spot start
        elif dt == Trade.spot:
            is_exact = True
            return Trade.l_grid_mne[0], is_exact, is_imm, is_bkwd_start

        at = Trade.sl_grid.bisect_right(dt)
        # is this past the last date on the grid ?
        if at >= len(Trade.l_grid_mne):
            is_exact = abs(Trade.sl_grid[-1] - dt) < 3
            return Trade.l_grid_mne[-1], is_exact, is_imm, is_bkwd_start

        if not skip_imm_check:
            mne_imm, is_exact_imm, is_imm = self.imm_grid_snap(dt, _what_is_exact_=0)
            # if this is an imm we still need to go ahead and verify
            # if we have an strict and exact match on the standard dates grid
            # if we do - that take precidence...
            if is_imm:
                mne_standard, is_exact = self.standard_grid_snap(dt, _what_is_exact_=0)
                if is_exact:
                    return mne_standard, is_exact, is_imm, is_bkwd_start
                else:
                    return mne_imm, is_exact_imm, is_imm, is_bkwd_start

        mne_standard, is_exact = self.standard_grid_snap(dt, _what_is_exact_=2)
        return mne_standard, is_exact, is_imm, is_bkwd_start

    def calc_dv01(self):
        if self.i_startDt > Trade.spot:
            at_start = Trade.l_grid_mne_all.index(self.start_snap)
            self.risk[at_start] = -Trade.l_dv01s[at_start] * self.notnl / 10_000_000

        at_end = Trade.l_grid_mne_all.index(self.end_snap)
        self.risk[at_end] = Trade.l_dv01s[at_end] * self.notnl / 10_000_000

    def dates_for_display(self):
        # start label
        s = None
        # end label
        e = None

        if self.is_spot_start:
            s = "spot"
        elif self.is_bkwd_start:
            s = self.startDt.strftime("%d%b%y")
        elif self.is_start_exact:
            s = self.start_snap
        else:
            s = self.startDt.strftime("%d%b%y")

        if self.is_bkwd_start:
            e = self.endDt.strftime("%d%b%y")
        elif self.is_end_exact or self.is_spot_start:
            e = self.end_snap
        else:
            e = self.endDt.strftime("%d%b%y")

        return s, e, self.tenor_snap

    def describe(self):
        (start, end, tenor) = self.dates_for_display()
        print(f"{start} x {end} notnl = {self.notnl}")
        print(f"pkg = {self.is_pkg} @ type = {self.lvl_type} lvl = {self.lvl}")

    def invoice_label(self):
        if self.is_invoice_compatible is False:
            return ''
        fut_name_len = len(self.invoice_fut)-3
        fut_contract_name = self.invoice_fut[:fut_name_len].upper()
        fut_contract_month = self.invoice_fut[fut_name_len:]
        return f"{fut_contract_name}{fut_contract_month}({self.invoice_setl})"

    def mms_label(self):
        if self.is_mms_compatible is False:
            return ''
        return self.bond

    def fomc_label(self):
        if self.is_fomc_compatible is False:
            return ''
        return self.fomc[0]

    def is_identical_with_diff_ts(self, t2):
        if self.startDt != t2.startDt:
            return False
        if self.endDt != t2.endDt:
            return False
        if self.fxd_rate_leg != t2.fxd_rate_leg:
            return False
        if self.sprd_leg != t2.sprd_leg:
            return False
        if self.other_pymt_amt != t2.other_pymt_amt:
            return False

        # if the timestamps match then we want it to be grouped with the same package...
        if self.evtDt == t2.evtDt:
            return False

        return True
