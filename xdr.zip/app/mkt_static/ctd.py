import json
from datetime import datetime
import finglib.date as fdate
from enum import StrEnum


class BondFutureSetlType(StrEnum):
    EARLY = 'e'
    LATE = 'l'
    NUL = ''


class BondFutureCTD:
    @classmethod
    def from_file(cls, cfg_path):
        cfg_file = f"{cfg_path}ctd_static_json.cfg"
        with open(cfg_file, "r") as f:
            j = json.load(f)
            ctd = BondFutureCTD()
            for bond_fut, l_static_info in j.items():
                for static_info in l_static_info:
                    if static_info is None:
                        break
                    bond = static_info['bond']
                    maturity_date = datetime.fromisoformat(static_info['maturity']).date()
                    maturity = fdate.datetime_to_excel(maturity_date)
                    early_delivery = datetime.fromisoformat(static_info['early']).date()
                    early = fdate.datetime_to_excel(early_delivery)
                    late_delivery = datetime.fromisoformat(static_info['late']).date()
                    late = fdate.datetime_to_excel(late_delivery)
                    ctd.add_static(bond_fut, bond, maturity, early, late)

            return ctd

    def __init__(self):
        self.d_early_maturity = {}
        self.d_late_maturity = {}
        self.l_bond_futs = []

    def add_static(self, bond_fut, bond, maturity, early, late):
        if bond_fut in self.l_bond_futs:
            i = self.l_bond_futs.index(bond_fut)
        else:
            i = len(self.l_bond_futs)
            self.l_bond_futs.insert(i, bond_fut)

        self.d_early_maturity[(early, maturity)] = i
        self.d_late_maturity[(late, maturity)] = i

    def for_start_end(self, start, end):
        dts = (start, end)
        if dts in self.d_early_maturity:
            at = self.d_early_maturity[dts]
            return self.l_bond_futs[at], BondFutureSetlType.EARLY
        elif dts in self.d_late_maturity:
            at = self.d_late_maturity[dts]
            return self.l_bond_futs[at], BondFutureSetlType.LATE
        else:
            return None, None


