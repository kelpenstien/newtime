import json
from datetime import datetime
import finglib.date as fdate


class UST:
    @classmethod
    def from_file(cls, cfg_path):
        cfg_file = f"{cfg_path}bond_static_json.cfg"
        with open(cfg_file, "r") as f:
            j = json.load(f)
            ust = UST()
            for ust_info in j:
                if ust_info is None:
                    break
                bond = ust_info['bond']
                maturity = datetime.fromisoformat(ust_info['maturity']).date()
                dt = fdate.datetime_to_excel(maturity)
                ust.add_static(bond, dt)
            return ust

    def __init__(self):
        self.d_maturity = {}
        self.l_bonds = []

    def add_static(self, bond, maturity):
        i = len(self.l_bonds)
        self.l_bonds.insert(i, bond)
        self.d_maturity[maturity] = i

    def for_maturity(self, maturity):
        if maturity not in self.d_maturity:
            return None
        at = self.d_maturity[maturity]
        return self.l_bonds[at]

