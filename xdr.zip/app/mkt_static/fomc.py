import json
from datetime import datetime
import finglib.date as fdate


class FOMC:
    @classmethod
    def from_file(cls, cfg_path):
        cfg_file = f"{cfg_path}fomc_static_json.cfg"
        with open(cfg_file, "r") as f:
            j = json.load(f)
            fomc = FOMC()
            for fomc_info in j:
                if fomc_info is None:
                    break
                start_dt = datetime.fromisoformat(fomc_info['start']).date()
                start = fdate.datetime_to_excel(start_dt)
                end_dt = datetime.fromisoformat(fomc_info['end']).date()
                end = fdate.datetime_to_excel(end_dt)
                jump = datetime.fromisoformat(fomc_info['jump_date']).date()
                fomc_meeting = fomc_info['fomc_meeting']

                fomc.add_static(fomc_meeting, start, end, jump)
            return fomc

    def __init__(self):
        self.d_rev_lookup = {}
        self.l_jumpdates = []

    def add_static(self, meeting_mne, start, end, jump):
        i = len(self.l_jumpdates)
        self.l_jumpdates.insert(i, (meeting_mne, jump))
        self.d_rev_lookup[(start, end)] = i

    def for_start_end(self, start, end):
        dts = (start, end)
        if dts in self.d_rev_lookup:
            at = self.d_rev_lookup[dts]
            return self.l_jumpdates[at]
        else:
            return None
