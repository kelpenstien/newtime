import os
import glob
import json

import finglib.err
import requests

from http_requests_wrapper import fire_http_request

from finglib.bind import fpx


class MktSnapshot:
    def __init__(self, cache_dir, asofdate):
        self.httpSession = requests.Session()
        self.asofdate = asofdate
        yyyy_mm_dd = asofdate.strftime("%Y_%m_%d")
        self.cache_dir = f'{cache_dir}mkt_cache\\{yyyy_mm_dd}'

        if os.path.isdir(self.cache_dir) is False:
            os.mkdir(self.cache_dir)
        self.l_cached_mkts = glob.glob("*.mkt", root_dir=self.cache_dir)

        mkt = "SF_"
        fpx().MktCreate(mkt)
        fingal_set_data = ['usdh15ff.hst.SetData', 'USD:1m:1m.SetData', 'USD:3m:3m.SetData', 'USD:SOFR.SetData']
        fpx().MktSetDataLoad(mkt, fingal_set_data)

        self.active_mkt = None

    def cache(self, mkt, utc_time):
        hhmmss = utc_time.strftime("%H%M%S")
        mkt_file_name = f'{self.cache_dir}\\{hhmmss}.mkt'
        fpx().MktSave(mkt, mkt_file_name, None, None, "CompressV4")
        self.l_cached_mkts.append(f'{hhmmss}.mkt')

    def format_time_parameter(self, utc_time):
        # abstract method must be overridden
        pass

    def load_for_utc(self, utc_time):
        # anything cached for within the prior 10 seconds of the requested time ?
        # if yes - use that to speed things up
        hhmmss = utc_time.strftime("%H%M%S")
        mkt_file_name = f'{self.cache_dir}\\{hhmmss}.mkt'

        if f'{hhmmss}.mkt' in self.l_cached_mkts:
            mkt = fpx().MktLoad("SF_", mkt_file_name)
        else:
            # time format for utc time is
            # yyyy.mm.ddThh:mm:ss.000000000
            self.params['time'] = self.format_time_parameter(utc_time)
            response = fire_http_request(self.httpSession, self.url, self.params, try_again_on_failure=False)
            if response is None:
                return None
            print(response.text)
            d = json.loads(response.text)
            if 'status' in d and d['status'] == "NOK":
                return None
            str_mkt_crv = d['def']
            mkt = fpx().MktLoadFromString("SF_", str_mkt_crv)
            fpx().MktSetDealDate(mkt, self.asofdate)
            fpx().MktSave("SF_", mkt_file_name)

        self.active_mkt = mkt
        return self.active_mkt


class KDBMktSnapshot(MktSnapshot):
    def __init__(self, cache_dir, asofdate):
        super().__init__(cache_dir, asofdate)
        self.url = "http://amp010225:8080/getCurve"
        self.params = {'group': 'USDPrc', 'curve': 'USD.KCurve'}

    def format_time_parameter(self, utc_time):
        return utc_time.strftime("%Y.%m.%dT%H:%M:%S.000000000")


class CurveWinderMktSnapshot(MktSnapshot):
    def __init__(self, cache_dir, asofdate):
        super().__init__(cache_dir, asofdate)
        self.url = "http://127.0.0.1:5006/kcurve"
        self.params = {}

    def format_time_parameter(self, utc_time):
        return utc_time.strftime("%Y-%m-%dT%H:%M:%S")


def get_swap_mid_as_of(snap, utc_time, startDt, endDt):
    if startDt < snap.asofdate:
        return None

    mkt = snap.load_for_utc(utc_time)
    if mkt is None:
        return None

    try:
        result = fpx().KCurveParSwapCoupon("SF_USD.KCurve", "SOFR", startDt, endDt)
    except finglib.err.FingalError as error:
        print(f"Error trying to get a mid off the live swap curve. {startDt} / {endDt} @ {utc_time}. Skipping.")
        print(f"{finglib.err.ExceptionToErrorString(error).to_string()}")
        return None

    for res in result:
        if res[1] == 'Par coup':
            return res[0]
    return None


