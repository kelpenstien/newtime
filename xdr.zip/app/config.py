import pickle
import os
import glob


class SearchQueryConfig:
    def __init__(self, config_dir):
        self.config_file_name = "sql_where_claus.pkl"
        if os.path.isdir(f"{config_dir}") is False:
            os.mkdir(f"{config_dir}")
        self.config_file = f"{config_dir}{self.config_file_name}"

    def load(self):
        if os.path.isfile(self.config_file):
            print(f"{self.config_file} already exists..., loading.")
            try:
                with open(self.config_file, "rb") as f_cfg:
                    return pickle.load(f_cfg)
            except EOFError as exp:
                return None
        return None

    def write(self, l_clauses):
        with open(self.config_file, "wb") as f_cfg:
            pickle.dump(l_clauses, f_cfg)


class SettingsConfig:
    def __init__(self, config_dir):
        self.settings_file_name = "settings.pkl"
        if os.path.isdir(f"{config_dir}") is False:
            os.mkdir(f"{config_dir}")
        self.settings_file = f"{config_dir}{self.settings_file_name}"

    def load(self):
        if os.path.isfile(self.settings_file):
            print(f"{self.settings_file} already exists..., loading.")
            try:
                with open(self.settings_file, "rb") as f_cfg:
                    return pickle.load(f_cfg)
            except EOFError as exp:
                return None
        return None

    def write(self, d_settings):
        with open(self.settings_file, "wb") as f_cfg:
            pickle.dump(d_settings, f_cfg)


def get_wav_location(config_dir):
    if os.path.isdir(f"{config_dir}") is False:
        return "app"
    # update with jingle path
    wav_files = glob.glob(f"{config_dir}\\bigboy.wav")
    return config_dir if len(wav_files) > 0 else "app"


